"""CleanFlow PC — conservative, offline Windows housekeeping."""
__version__ = '1.0.0'
