# CleanFlow PC

A real, offline Python/Tkinter Windows desktop cleaner. Conservative by default:
only user temporary files at least **7 days old** are selected; opening the app
never starts a scan or cleanup. Automatic cleaning and startup integration are off.

## Run on Windows 10 Pro

Recommended: **64-bit CPython 3.12** from python.org, with **Tcl/Tk and IDLE**
selected in the installer. Python 3.10–3.13 are intended targets. No runtime pip
packages, internet connection, account, API key or administrator rights are needed.

1. Extract this entire project to a permanent folder, for example
   `C:\Users\YourName\Apps\CleanFlowPC`.
2. Open Command Prompt in that folder.
3. Run:

   ```bat
   py -3.12 run_cleanflow.py
   ```

   Or create a virtual environment:

   ```bat
   py -3.12 -m venv .venv
   .venv\Scripts\python.exe run_cleanflow.py
   ```

4. Choose **Junk Scanner → Scan Now**. Review counts, sizes and **View Details**.
5. Open **Clean Files**. **Dry-run preview** is selected initially. Run it first.
6. Select **Move to Recycle Bin** or **Permanently delete** and explicitly approve
   the operation. Permanent deletion cannot be undone. Recycled files retain their
   original names and can be restored through Windows; recycling does not free
   disk space immediately.

Run `python -m tkinter` if Tkinter is missing; modify the Python installation to
add Tcl/Tk. Run from a Command Prompt to see any source startup error.

## Build a Windows executable

Build **on Windows**, using the same architecture you intend to distribute.
A Linux PyInstaller build cannot produce a Windows EXE. Build tools need an initial
download; the resulting application itself works fully offline.

From the extracted project folder:

```bat
py -3.12 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.venv\Scripts\python.exe -m unittest discover -s tests -v
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean CleanFlowPC.spec
```

Or run `build_windows.bat` (uses the default installed Python 3 interpreter).
The build stops if dependency installation or tests fail.

Launch **`dist\CleanFlowPC\CleanFlowPC.exe`**. Keep the **entire**
`dist\CleanFlowPC` folder together, including `_internal`; the EXE is a standalone
application requiring no separately installed Python. An onedir build avoids
repeated extraction and extra disk activity on older machines. No UAC manifest
requests elevation. UPX is disabled. This project does not provide a signed or
prebuilt EXE.

If you specifically need a single file:

```bat
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onefile --windowed --name CleanFlowPC run_cleanflow.py
```

That EXE appears at `dist\CleanFlowPC.exe`; it extracts its runtime on each start.
Choose a permanent install location **before** enabling automatic cleaning or
startup integration. If you move the source, virtual environment or EXE, register
the task again and toggle startup integration off and on.

For an offline build machine, download the build dependency wheels on another
Windows PC with the same Python version and architecture:

```bat
py -3.12 -m pip download -r requirements-build.txt -d wheelhouse
```

Copy this project and `wheelhouse`, then use:

```bat
.venv\Scripts\python.exe -m pip install --no-index --find-links wheelhouse -r requirements-build.txt
```

## Automatic cleaning

Open **Automatic Cleaning**. Choose daily, weekly (Monday) or after login. Time
uses the PC's local clock, in 24-hour format; login tasks wait two minutes and
ignore the time field. Choose the age threshold (1–3650 days), then **Enable /
Change**. The confirmation shows the **exact folders**, exclusions and retention
rule and explains that scheduled cleanup permanently deletes files.

- Uses Windows Task Scheduler with your Windows SID, `InteractiveToken` and
  `LeastPrivilege`. It stores no password, requires no administrator prompt, and
  operates while your Windows user session is signed in, including a locked session.
- No GUI opens for a scheduled run. Only approved user temporary files are scanned.
  Prefetch, browser caches, system temp, crash dumps and Recycle Bin are excluded.
- **Enable / Change** creates or replaces the current user's task. **Enable
  existing** re-enables its approved definition. **Disable** retains it;
  **Delete task** removes it. Disabled automatic cleaning means manual cleaning only.
- **Check task** queries Windows and displays the task's state alongside local
  authorization. No fake scheduler status is inferred from preferences.
- Local authorization is switched off before task mutations. If disabling a task
  fails, a later invocation still exits without deleting anything.
- Changing retention, exclusions or discovered user temp paths requires approval
  again. Unapproved or malformed configuration fails closed.
- The task does not wake the PC or require network access. Missed daily/weekly
  runs may start when available. A run has a one-hour Task Scheduler limit.
- Task Scheduler ignores overlapping instances. OS file locks also prevent
  simultaneous cleanup by GUI and background runs. Cancellation finishes the current
  file before stopping. Hard termination can interrupt result/history recording;
  individual file operations remain atomic.

The command registered by the app is either `CleanFlowPC.exe --scheduled` or the
installed Python interpreter and an absolute `run_cleanflow.py --scheduled` path.
Task name: `CleanFlowPC-<12-character hash of your Windows SID>`.

## Scope and safety

| Category | Locations | Default | Scheduled |
| --- | --- | --- | --- |
| User temporary files | `%LOCALAPPDATA%\Temp`; `%TEMP%` when inside that canonical tree | Selected | Yes, with separate approval |
| Windows temporary files | `%WINDIR%\Temp` | Off | Never |
| Browser caches | Chrome/Edge Default and Profile * cache, Code Cache and GPUCache; Firefox local profile cache2 | Off | Never |
| Crash dumps | `%LOCALAPPDATA%\CrashDumps`, `%WINDIR%\Minidump`, `%WINDIR%\LiveKernelReports` | Off | Never |
| Prefetch | `%WINDIR%\Prefetch` | Off; extra manual warning | Never |
| Recycle Bin | Current user's Windows Shell size/item query | Off; read only | Never |

`SystemRoot` is used if `WINDIR` is absent. Nonexistent folders are ignored.
Overlapping roots/files are deduplicated. The most specific approved root owns a
file's category. An environment override pointing TEMP at an arbitrary folder is
intentionally not accepted; there is no option to add arbitrary cleanup roots.
Recycle Bin contents are never emptied by this app. Review and empty them using
Windows; **View Details → Open Windows Recycle Bin** provides access.

All categories use the selected age rule. Eligibility depends on approved folder,
age, permissions, identity and file attributes, not a file extension. There are
no Downloads, Desktop, Documents, Pictures, Videos, application-install, game-save,
Windows Update database, restore-point, registry or security-log cleanup targets.
The app never force-closes a program, resets permissions, disables a security
service, or runs a recursive delete command. It offers no RAM/CPU optimization.

The engine rejects folder roots, directories, `..` traversal, alternate streams,
UNC paths, symbolic links, junctions, other reparse points, hard-linked files and
read-only/system/offline files. It lstat-checks the whole path and compares size,
mtime, ctime, device and file ID against the scan. Windows native change time is
also captured and checked, including edits whose modification time was restored.

Permanent deletion opens every ancestor without delete sharing to prevent
renames, rejects reparse points by handle, opens the leaf exclusively, checks its
final path and identity again, then marks **that file handle** for deletion.
Nothing deletes directory roots or recursively removes a directory. Busy or
inaccessible files are skipped. Files whose identity cannot be established are
left alone. ReFS/file systems with incompatible IDs may therefore be skipped.

Recycling queues the verified file with Windows `IFileOperation`, requires
`FOFX_RECYCLEONDELETE`, and disables recursion/reparse traversal and elevation UI.
Unsupported recycling fails; there is no permanent-delete fallback. It retains
ancestor locks throughout. The exclusive leaf handle must be released immediately
before the Shell performs the move: recycling is consequently a Shell path-based
operation rather than the handle-level identity guarantee of permanent deletion.
This utility is intended for ordinary local Windows use; it is not a security
boundary against malicious processes running under the same Windows account.

Storage numbers are honest estimates. The scan shows logical eligible bytes
before locked-file checks. After permanent deletion, the reported freed bytes use
the smaller of file allocation and logical size; actual volume free space can
change independently due to compression, metadata and other activity. Recycled
bytes are reported separately and never added to freed space. A new dashboard
scan is needed after cleanup to estimate remaining junk.

## Interface and local data

Six real pages: Dashboard, Junk Scanner, Clean Files, Automatic Cleaning, Cleaning
History and Settings. Both themes use ttk; Windows uses Segoe UI. Background
workers scan/clean; only the main thread touches Tk. Progress events use a bounded
queue and scan updates are throttled. Stop Scan/Stop Job cancels ongoing work.
Closing during a job requests cancellation and waits for it to finish.

For predictable resource use, each scan processes at most 250,000 files and retains
at most 50,000 eligible candidates. A limit produces an explicit partial-batch
notice, not a complete-drive claim. Clean a batch and rescan, or narrow categories
and exclusions. Details show the first 1,000 eligible paths and up to 1,000
diagnostics, with separate eligible/skipped/failed tabs; totals cover the full
processed batch. Very large or blocked OS calls may delay cancellation until the
current call returns.

Preferences and aggregate history live under **`%LOCALAPPDATA%\CleanFlowPC`**:

- `settings.json`: atomically saved preferences and explicit schedule approval.
- `history.sqlite3`: most recent 200 cleanup/dry-run summaries, including counts,
  freed/recycled bytes, duration and cancellation. No file paths or contents are
  saved in history. Diagnostic paths remain in the current session only.
- `cleanup.lock`, `scheduled-entry\cleanup.lock`: OS-managed job locks. A crash
  releases a lock automatically; files remaining on disk are harmless.

Completion notifications are an in-app dialog and a Windows notification sound
for background runs. They are configurable; there is no network notification
service. Optional startup integration writes only the current user's
`HKCU\Software\Microsoft\Windows\CurrentVersion\Run\CleanFlowPC` value and opens
the app without cleaning anything. Permanent-deletion confirmation is deliberately
always on; it cannot be disabled in Settings. Scheduled approval is separate.

To remove the application, disable/delete its task and turn startup integration
off, close the app, then remove its project/install folder. You may separately
remove `%LOCALAPPDATA%\CleanFlowPC` if you want to discard preferences/history.

## Tests and verification

```bat
py -3.12 -m unittest discover -s tests -v
py -3.12 scripts\gui_smoke.py
```

The unit suite uses disposable test folders, never live Windows cleanup locations.
It covers retention, changed files, forged outside candidates, sibling-prefix and
`..` attacks, root preservation, exclusions, links/hard links, overlapping roots,
cancellation, authorization, Prefetch restrictions, scan limits, settings recovery,
history privacy, job locks, scheduled scope and Task Scheduler XML.

Three Windows-only tests exercise real handle deletion, open-file skipping and a
real junction in a disposable directory. Symbolic-link tests may skip on Windows
accounts without link-creation permission. The GUI smoke script renders all six
pages, scans 3,001 temporary test files while a main-thread heartbeat runs, verifies
1,501 files in dry-run, and exercises details and theme persistence. It never
performs a real cleanup. Its optional screenshot capture uses Pillow only when
`CLEANFLOW_SCREENSHOT` is set; Pillow is not an app dependency.

See **VERIFICATION.md** for the actual checks run in the delivery environment.
Windows Shell recycling, task registration/startup and a packaged EXE need a real
Windows acceptance run; Linux tests cannot establish those integrations work.

## Project structure

```text
run_cleanflow.py             GUI entry point and --scheduled dispatch
cleanflow/gui.py             Tkinter/ttk pages, worker queue and confirmations
cleanflow/engine.py          Scanning, batch limits, cancellation and results
cleanflow/policy.py          Allowlist, path, age, identity and attribute checks
cleanflow/paths.py           Environment-based closed catalog and deduplication
cleanflow/native.py          Windows handle operations, Shell recycling/bin query
cleanflow/scheduler.py       Current-user Task Scheduler XML and startup registry
cleanflow/storage.py         JSON preferences, bounded SQLite history and OS locks
cleanflow/models.py          Category, scan, candidate and result data
cleanflow/__main__.py        Approved unattended execution without GUI
CleanFlowPC.spec             Non-elevated PyInstaller onedir build
build_windows.bat           Build dependencies, tests and Windows packaging
requirements*.txt           Standard-library runtime and pinned build dependency
tests/                      Disposable-folder tests; native tests gated to Windows
scripts/gui_smoke.py         Non-destructive GUI integration check
```
