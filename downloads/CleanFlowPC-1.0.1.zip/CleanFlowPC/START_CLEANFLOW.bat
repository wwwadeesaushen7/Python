@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 goto folder_error
title CleanFlow PC - Launcher

if exist "dist\CleanFlowPC\CleanFlowPC.exe" goto built
if exist ".venv\Scripts\python.exe" goto virtual_environment
where py >nul 2>&1
if errorlevel 1 goto try_python
py -3.12 -c "import sys; sys.exit(sys.version_info[:2] != (3,12))" >nul 2>&1
if errorlevel 1 goto try_default_launcher
set "PY_COMMAND=py -3.12"
goto source

:try_default_launcher
py -3 -c "import sys; sys.exit(sys.version_info < (3,10))" >nul 2>&1
if errorlevel 1 goto try_python
set "PY_COMMAND=py -3"
goto source

:try_python
python -c "import sys; sys.exit(sys.version_info < (3,10))" >nul 2>&1
if errorlevel 1 goto no_python
set "PY_COMMAND=python"
goto source

:virtual_environment
set "PY_COMMAND=.venv\Scripts\python.exe"

:source
if not exist "run_cleanflow.py" goto missing_files
if not exist "cleanflow\gui.py" goto missing_files
echo Starting CleanFlow PC. Leave this window open while the app is running.
%PY_COMMAND% run_cleanflow.py
if errorlevel 1 goto failed
exit /b 0

:built
echo Starting the built CleanFlow PC app...
start "" /wait "%~dp0dist\CleanFlowPC\CleanFlowPC.exe"
if errorlevel 1 goto failed
exit /b 0

:no_python
echo ERROR: Python 3.10 or newer was not found.
echo Install Python 3.12 from python.org with Tcl/Tk and the Python launcher.
echo Then reopen START_CLEANFLOW.bat. No build or pip packages are needed to run source.
pause
exit /b 1

:missing_files
echo ERROR: Required application files are missing.
echo Right-click CleanFlowPC.zip and choose Extract All.
echo Open START_CLEANFLOW.bat from the extracted CleanFlowPC folder.
pause
exit /b 1

:failed
echo.
echo CleanFlow PC stopped with an error. The window will stay open.
echo Read the error above, or check:
echo %LOCALAPPDATA%\CleanFlowPC\startup-error.log
echo If that folder could not be written, check %TEMP%\CleanFlowPC\startup-error.log.
echo Copy the last error lines so the problem can be diagnosed.
pause
exit /b 1

:folder_error
echo ERROR: Extract the ZIP into a folder you can open, then try again.
pause
exit /b 1
