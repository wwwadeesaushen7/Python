# Verification — CleanFlow PC 1.0.1 — 23 October 2026

Executed on Linux with CPython 3.12.14 and Tk 9.0. No real Windows system/user
cleanup locations were scanned or modified.

- `python -m unittest discover -s tests -v`: **43 tests, 40 passed, 3 skipped**.
  The three skipped tests require Windows native APIs. All portable safety,
  cancellation, storage, locking and schedule-policy tests passed.
- Startup diagnostics tests additionally cover missing Tkinter, main-module import
  failure, unavailable stderr in windowed builds, local log fallback, bounded log
  size, and the rule that unattended runs never show startup dialogs.
- `python -m compileall -q cleanflow tests scripts run_cleanflow.py`: passed.
- `python -m cleanflow --scheduled`: exited with status 0, without importing Tk,
  opening a GUI or cleaning anything on the non-Windows host.
- `python -m cleanflow --help`: CLI argument handling passed.
- `scripts/gui_smoke.py` under an Xorg dummy display: all six pages rendered;
  3,001 disposable files were scanned on a worker thread while the main event
  loop heartbeat continued; 1,501 eligible files were verified in dry-run; details,
  dark/light theme switching and saved preferences passed. No files were deleted.
- Manual source audit: cleanup does not use recursive directory deletion, shell
  command strings, permission escalation or permission changes. Native permanent
  removal uses verified file handles; Shell recycle uses recycle-only flags.

The 1.0.1 launcher/build scripts now pause on errors and the build opens its EXE
after success. These Windows batch scripts were reviewed but could not be executed
on this Linux host. The existing GUI pages and cleanup policies are unchanged.

Not executed here: the Windows-only tests; Windows Shell recycling; real Task
Scheduler creation/enable/disable/delete and logon behavior; startup registry
integration; PyInstaller compilation and launch of a Windows EXE. No prebuilt EXE
is included, and this report does not claim Windows acceptance is complete.

## Windows acceptance sequence

1. Run the full test suite. The real native deletion/open-file/junction tests must
   pass before relying on actual cleanup. Link-creation privilege skips are noted
   separately by unittest; the junction test uses a disposable junction.
2. Launch the app as a standard Windows user. Confirm default category is user
   temp, dry-run mode is selected, automatic cleaning is off, and opening the app
   does not scan or delete anything. Check all six pages and both themes.
3. Create a disposable file under the canonical user Temp folder, give it an mtime
   at least eight days old, and exclude unrelated temp content if desired. Scan
   and dry-run. Verify a recent file is skipped. The whole selected category is
   scanned, so review all eligible files before authorizing any cleanup.
4. If you want to test a real cleanup, explicitly authorize it in the GUI. Compare
   changed/busy-file skips and results. For recycle mode, verify the file appears
   in Windows Recycle Bin with its original name and can be restored. Do not empty
   unrelated bin contents. Test an unsupported destination only with a disposable
   file; it must fail rather than permanently delete it.
5. Enable a daily, weekly or login task after reviewing the exact displayed scope
   and retention. Check its definition in Windows Task Scheduler: current-user
   SID, least privilege, interactive token, `--scheduled`, no Prefetch, no password.
   This approval covers the displayed eligible user temp files, not just a test
   file. Use a retention/exclusion policy you intend to authorize.
6. Confirm disable/enable/delete controls and that changed retention/exclusions
   turn local automatic approval off. Verify normal signed-in runs record aggregate
   history, run without a GUI, and do not overlap manual cleanup.
7. Toggle startup integration, check the current user's Run value and turn it off
   again if it is not wanted. Startup should open only the interface.
8. Build with `build_windows.bat`, copy the entire built directory to a stable
   location, launch the EXE and repeat smoke checks. If paths moved, register the
   scheduled task/startup integration again.
