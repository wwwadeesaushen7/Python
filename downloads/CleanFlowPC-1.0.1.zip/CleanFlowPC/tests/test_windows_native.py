"""Real native calls only against disposable test folders; run on Windows."""
import os
from pathlib import Path
import subprocess
import tempfile
import time
import unittest
from cleanflow.models import Root
from cleanflow.policy import Policy
from cleanflow import engine

@unittest.skipUnless(os.name == 'nt', 'Windows native API requires Windows')
class WindowsNativeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name).resolve()
        self.root = self.base / 'approved'
        self.root.mkdir()
        self.file = self.root / 'old.tmp'
        self.file.write_bytes(b'test data')
        stamp = time.time() - 10 * 86400
        os.utime(self.file, (stamp, stamp))
        self.policy = Policy([Root(self.root, 'user_temp')])

    def tearDown(self):
        self.tmp.cleanup()

    def test_real_handle_deletion_keeps_roots(self):
        out = engine.clean(engine.scan(self.policy, {'user_temp'}), self.policy,
                           'permanent', authorized=True, lock_dir=self.base / 'state')
        self.assertEqual((out.cleaned, out.failed, out.skipped), (1, 0, 0), out.details)
        self.assertFalse(self.file.exists())
        self.assertTrue(self.root.is_dir())

    def test_open_file_is_skipped(self):
        preview = engine.scan(self.policy, {'user_temp'})
        with self.file.open('rb'):
            out = engine.clean(preview, self.policy, 'permanent', authorized=True, lock_dir=self.base / 'state')
        self.assertEqual(out.cleaned, 0)
        self.assertEqual(out.skipped, 1)
        self.assertTrue(self.file.exists())

    def test_real_junction_cannot_escape(self):
        outside = self.base / 'outside'
        outside.mkdir()
        secret = outside / 'personal.txt'
        secret.write_text('preserve')
        link = self.root / 'junction'
        # Only creates a junction in this test's own temporary directory.
        result = subprocess.run(['cmd.exe', '/c', 'mklink', '/J', str(link), str(outside)], capture_output=True)
        if result.returncode:
            self.skipTest('Junction creation unavailable')
        try:
            preview = engine.scan(self.policy, {'user_temp'})
            self.assertNotIn(secret, [c.path for c in preview.candidates])
            out = engine.clean(preview, self.policy, 'permanent', authorized=True, lock_dir=self.base / 'state')
            self.assertTrue(secret.exists())
        finally:
            link.rmdir()

if __name__ == '__main__':
    unittest.main()
