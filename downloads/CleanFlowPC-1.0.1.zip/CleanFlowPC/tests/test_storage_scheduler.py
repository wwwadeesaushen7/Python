import datetime as dt
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
import xml.etree.ElementTree as ET
from unittest.mock import patch
from cleanflow.storage import Settings, History, JobLock
from cleanflow.models import Result, Root
from cleanflow.scheduler import build_xml, approval, NS, task_name

class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.folder = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_defaults_and_round_trip(self):
        s = Settings(self.folder)
        self.assertFalse(s.values['automatic'])
        self.assertEqual(s.values['days'], 7)
        s.values.update(days=14, theme='light', exclusions=[str(self.folder / 'exclude')])
        s.save()
        self.assertEqual(Settings(self.folder).values, s.values)

    def test_corrupt_settings_fail_closed(self):
        for content in ('broken', '[]', '{"days":0,"automatic":true}', '{"automatic":"yes"}'):
            (self.folder / 'settings.json').write_text(content)
            s = Settings(self.folder)
            self.assertFalse(s.values['automatic'])
            self.assertTrue(s.warning)

    def test_permanent_confirmation_cannot_be_disabled(self):
        s = Settings(self.folder)
        s.values['confirm_permanent'] = False
        s.save()
        self.assertTrue(Settings(self.folder).values['confirm_permanent'])

    def test_lock_exclusion_and_release(self):
        with JobLock(self.folder):
            with self.assertRaises(RuntimeError):
                with JobLock(self.folder):
                    pass
        with JobLock(self.folder):
            pass

    def test_history_bounded_and_private(self):
        history = History(self.folder)
        result = Result(cleaned=2, details=[('Failed', 'sensitive-name', 'contents')])
        for i in range(205):
            result.scanned = i
            history.add(result)
        rows = history.rows()
        self.assertEqual(len(rows), 200)
        self.assertEqual(rows[0]['scanned'], 204)
        self.assertNotIn('sensitive-name', history.path.read_bytes().decode('latin1'))
        self.assertNotIn('details', rows[0])

class ScheduleTests(unittest.TestCase):
    def xml(self, frequency='daily', exe=r'C:\Apps & Tools\CleanFlowPC.exe', args=None):
        return ET.fromstring(build_xml('S-1-5-21-123', frequency, '10:30', exe, args or ['--scheduled'],
                             now=dt.datetime(2026, 10, 23, 9)))

    def text(self, root, path):
        return root.find('/'.join('{' + NS + '}' + p for p in path.split('/'))).text

    def test_least_privilege_interactive_no_overlap(self):
        root = self.xml()
        self.assertEqual(self.text(root, 'Principals/Principal/RunLevel'), 'LeastPrivilege')
        self.assertEqual(self.text(root, 'Principals/Principal/LogonType'), 'InteractiveToken')
        self.assertEqual(self.text(root, 'Settings/MultipleInstancesPolicy'), 'IgnoreNew')
        self.assertEqual(self.text(root, 'Actions/Exec/Arguments'), '--scheduled')
        self.assertEqual(self.text(root, 'Actions/Exec/Command'), r'C:\Apps & Tools\CleanFlowPC.exe')

    def test_triggers(self):
        for freq, name in [('daily', 'CalendarTrigger'), ('weekly', 'CalendarTrigger'), ('logon', 'LogonTrigger')]:
            root = self.xml(freq)
            self.assertIsNotNone(root.find(f'{{{NS}}}Triggers/{{{NS}}}{name}'))
        root = self.xml('weekly')
        self.assertIsNotNone(root.find(f'.//{{{NS}}}Monday'))

    def test_invalid_schedule(self):
        with self.assertRaises(ValueError):
            build_xml('S-1-5-1', 'yearly', '10:00', 'program', [])
        with self.assertRaises(ValueError):
            build_xml('S-1-5-1', 'daily', 'bad', 'program', [])

    def test_approval_snapshots_exact_scope(self):
        roots = [Root(Path('/temp'), 'user_temp'), Root(Path('/prefetch'), 'prefetch')]
        a = approval(roots, 7, ['/temp/excluded'])
        self.assertEqual(a['roots'], [os.path.normcase(str(Path('/temp')))])
        self.assertNotEqual(a, approval(roots, 8, ['/temp/excluded']))
        self.assertEqual(task_name('S-1-5-1'), task_name('S-1-5-1'))
        self.assertNotEqual(task_name('S-1-5-1'), task_name('S-1-5-2'))

    def test_unapproved_scheduled_entry_does_nothing(self):
        from cleanflow.__main__ import scheduled
        with patch('cleanflow.__main__.Settings') as SettingsMock, patch('cleanflow.__main__.engine.scan') as scan:
            SettingsMock.return_value.values = {'automatic': False}
            self.assertEqual(scheduled(), 0)
            scan.assert_not_called()

if __name__ == '__main__':
    unittest.main()

class ScheduledScopeTests(unittest.TestCase):
    def test_changed_approval_does_not_scan(self):
        from cleanflow.__main__ import scheduled
        v = dict(automatic=True, days=7, exclusions=[], schedule_approval={'roots': ['wrong']})
        roots = [Root(Path('/approved'), 'user_temp')]
        with patch('cleanflow.__main__.sys.platform', 'win32'), patch('cleanflow.__main__.Settings') as s, \
             patch('cleanflow.__main__.discover', return_value=roots), patch('cleanflow.__main__.engine.scan') as scan:
            s.return_value.values = v
            self.assertEqual(scheduled(), 2)
            scan.assert_not_called()

    def test_approved_job_only_receives_user_temp(self):
        from cleanflow.__main__ import scheduled
        from cleanflow.models import Scan, Result
        with tempfile.TemporaryDirectory() as temporary:
            roots = [Root(Path(temporary) / 'Temp', 'user_temp'), Root(Path(temporary) / 'Prefetch', 'prefetch')]
            v = dict(automatic=True, days=14, exclusions=[], notifications=False,
                     schedule_approval=approval(roots, 14, []))
            with patch('cleanflow.__main__.sys.platform', 'win32'), patch('cleanflow.__main__.Settings') as s, \
                 patch('cleanflow.__main__.discover', return_value=roots), patch('cleanflow.__main__.data_dir', return_value=Path(temporary)), \
                 patch('cleanflow.__main__.History') as history, patch('cleanflow.__main__.engine.scan', return_value=Scan()) as scan, \
                 patch('cleanflow.__main__.engine.clean', return_value=Result()) as clean:
                s.return_value.values = v
                self.assertEqual(scheduled(), 0)
                policy, categories = scan.call_args.args
                self.assertTrue(policy.scheduled)
                self.assertEqual(categories, {'user_temp'})
                self.assertEqual([r.category for r in policy.roots], ['user_temp'])
                self.assertEqual(policy.days, 14)
                self.assertTrue(clean.call_args.kwargs['authorized'])
                history.return_value.add.assert_called_once()
