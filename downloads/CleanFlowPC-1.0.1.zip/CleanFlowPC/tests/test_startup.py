import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import run_cleanflow


class StartupTests(unittest.TestCase):
    def test_normal_launch_returns_status_without_error_ui(self):
        with patch.object(run_cleanflow, 'show_startup_error') as show, \
             patch.object(run_cleanflow, 'save_startup_error') as save:
            self.assertEqual(run_cleanflow.launch(lambda: 0), 0)
            show.assert_not_called()
            save.assert_not_called()

    def test_startup_failure_survives_missing_tk_and_stderr(self):
        def broken():
            raise ModuleNotFoundError("No module named '_tkinter'")
        with tempfile.TemporaryDirectory() as folder, \
             patch.object(run_cleanflow.sys, 'argv', ['run_cleanflow.py']), \
             patch.object(run_cleanflow.sys, 'stderr', None), \
             patch.object(run_cleanflow, 'show_startup_error') as show:
            self.assertEqual(run_cleanflow.launch(broken, folder), 1)
            text = (Path(folder) / 'startup-error.log').read_text(encoding='utf-8')
            self.assertIn('ModuleNotFoundError', text)
            self.assertIn('_tkinter', text)
            self.assertIn('startup-error.log', show.call_args.args[0])

    def test_main_module_import_failure_is_caught(self):
        with tempfile.TemporaryDirectory() as folder, \
             patch.dict(run_cleanflow.sys.modules, {'cleanflow.__main__': None}), \
             patch.object(run_cleanflow.sys, 'argv', ['run_cleanflow.py']), \
             patch.object(run_cleanflow.sys, 'stderr', io.StringIO()), \
             patch.object(run_cleanflow, 'show_startup_error') as show:
            self.assertEqual(run_cleanflow.launch(log_folder=folder), 1)
            show.assert_called_once()
            self.assertIn('cleanflow.__main__', (Path(folder) / 'startup-error.log').read_text(encoding='utf-8'))

    def test_unwritable_data_directory_falls_back_to_temp(self):
        with tempfile.TemporaryDirectory() as folder:
            blocked = Path(folder) / 'not-a-folder'
            blocked.write_text('existing file')
            fallback = Path(folder) / 'fallback'
            with patch.dict(run_cleanflow.os.environ, {'LOCALAPPDATA': str(blocked)}), \
                 patch.object(run_cleanflow.tempfile, 'gettempdir', return_value=str(fallback)):
                path = run_cleanflow.save_startup_error('test error')
            self.assertEqual(path, fallback / 'CleanFlowPC' / 'startup-error.log')
            self.assertIn('test error', path.read_text(encoding='utf-8'))

    def test_scheduled_import_failure_never_opens_a_dialog(self):
        def broken():
            raise ImportError('bad native module')
        with tempfile.TemporaryDirectory() as folder, \
             patch.object(run_cleanflow.sys, 'argv', ['run_cleanflow.py', '--scheduled']), \
             patch.object(run_cleanflow.sys, 'stderr', io.StringIO()), \
             patch.object(run_cleanflow, 'show_startup_error') as show:
            self.assertEqual(run_cleanflow.launch(broken, folder), 1)
            show.assert_not_called()
            self.assertTrue((Path(folder) / 'startup-error.log').exists())

    def test_traceback_size_is_bounded_and_replaced(self):
        with tempfile.TemporaryDirectory() as folder:
            path = run_cleanflow.save_startup_error('a' * 100000, folder)
            self.assertLessEqual(len(path.read_text(encoding='utf-8')), 65536)
            self.assertEqual(run_cleanflow.save_startup_error('new error', folder), path)
            self.assertIn('new error', path.read_text(encoding='utf-8'))
            self.assertLess(path.stat().st_size, 1024)

    def test_failure_to_save_log_still_reports_error(self):
        def broken():
            raise RuntimeError('cannot start')
        with patch.object(run_cleanflow, 'save_startup_error', return_value=None), \
             patch.object(run_cleanflow, 'show_startup_error') as show, \
             patch.object(run_cleanflow.sys, 'argv', ['run_cleanflow.py']), \
             patch.object(run_cleanflow.sys, 'stderr', io.StringIO()):
            self.assertEqual(run_cleanflow.launch(broken), 1)
            self.assertIn('could not be saved', show.call_args.args[0])


if __name__ == '__main__':
    unittest.main()
