import os
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
from cleanflow.models import Root, Candidate
from cleanflow.policy import Policy, UnsafeFile
from cleanflow.paths import discover, deduplicate
from cleanflow import engine

class SafetyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name).resolve()
        self.root = self.base / 'approved'
        self.root.mkdir()
        self.outside = self.base / 'personal'
        self.outside.mkdir()
        self.policy = Policy([Root(self.root, 'user_temp')])
        self.old = self.file(self.root / 'old.tmp')
        self.lock = self.base / 'state'

    def tearDown(self):
        self.tmp.cleanup()

    def file(self, path, content=b'abc', days=10):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        stamp = time.time() - days * 86400
        os.utime(path, (stamp, stamp))
        return path

    def preview(self):
        return engine.scan(self.policy, {'user_temp'})

    def test_default_retention_and_stats(self):
        self.file(self.root / 'fresh.tmp', days=1)
        out = self.preview()
        self.assertEqual(out.scanned, 2)
        self.assertEqual(out.skipped, 1)
        self.assertEqual([c.path for c in out.candidates], [self.old])
        self.assertEqual(out.stats['user_temp'], dict(files=2, bytes=6, eligible=1, reclaimable=3))

    def test_dry_run_never_calls_deletion(self):
        with patch('cleanflow.engine.native.permanent') as delete, patch('cleanflow.engine.native.recycle') as recycle:
            out = engine.clean(self.preview(), self.policy, lock_dir=self.lock)
        delete.assert_not_called()
        recycle.assert_not_called()
        self.assertEqual(out.previewed, 1)
        self.assertEqual(out.freed, 0)
        self.assertTrue(self.old.exists())

    def test_requires_authorization_and_valid_mode(self):
        with self.assertRaises(PermissionError):
            engine.clean(self.preview(), self.policy, 'permanent', lock_dir=self.lock)
        with self.assertRaises(ValueError):
            engine.clean(self.preview(), self.policy, 'recursive', lock_dir=self.lock)

    def test_no_root_directory_or_sibling_prefix(self):
        sibling = self.file(self.base / 'approved-other' / 'data')
        for path in (self.root, sibling, self.outside, self.base):
            with self.subTest(path=path), self.assertRaises(UnsafeFile):
                self.policy.validate(path, time.time())

    def test_traversal_is_rejected(self):
        self.file(self.outside / 'secret.tmp')
        for path in (self.root / '..' / 'personal' / 'secret.tmp', self.root / '..' / 'approved' / 'old.tmp'):
            with self.assertRaises(UnsafeFile):
                self.policy.validate(path, time.time())

    def symlink(self, target, link, directory=False):
        try:
            link.symlink_to(target, target_is_directory=directory)
        except (OSError, NotImplementedError):
            self.skipTest('Symbolic links unavailable for this user')

    def test_symlink_file_and_directory_not_followed(self):
        secret = self.file(self.outside / 'secret')
        self.symlink(secret, self.root / 'link.tmp')
        self.symlink(self.outside, self.root / 'junction', directory=True)
        out = self.preview()
        self.assertEqual(len(out.candidates), 1)
        self.assertEqual(out.skipped, 2)
        with self.assertRaises(UnsafeFile):
            self.policy.validate(self.root / 'junction' / 'secret', time.time())

    def test_root_or_ancestor_symlink_not_followed(self):
        alias = self.base / 'alias'
        self.symlink(self.root, alias, directory=True)
        policy = Policy([Root(alias, 'user_temp')])
        out = engine.scan(policy, {'user_temp'})
        self.assertFalse(out.candidates)
        self.assertEqual(out.skipped, 1)

    def test_hardlinks_rejected(self):
        try:
            os.link(self.old, self.root / 'second')
        except OSError:
            self.skipTest('Hard links unavailable')
        out = self.preview()
        self.assertFalse(out.candidates)
        self.assertEqual(out.skipped, 2)

    def test_exclusion_only_reduces_scope(self):
        policy = Policy(self.policy.roots, exclusions=[self.old, self.outside])
        self.assertFalse(engine.scan(policy, {'user_temp'}).candidates)
        self.assertEqual(len(engine.scan(self.policy, {'user_temp'}).candidates), 1)

    def test_replacement_after_scan_never_reaches_deletion(self):
        preview = self.preview()
        self.old.unlink()
        self.file(self.old, content=b'replacement')
        with patch('cleanflow.engine.native.permanent') as delete:
            out = engine.clean(preview, self.policy, 'permanent', authorized=True, lock_dir=self.lock)
        delete.assert_not_called()
        self.assertEqual(out.skipped, 1)

    def test_same_size_same_mtime_edit_is_rejected(self):
        preview = self.preview()
        expected = preview.candidates[0]
        self.old.write_bytes(b'new')
        os.utime(self.old, ns=(expected.mtime_ns, expected.mtime_ns))
        with patch('cleanflow.engine.native.permanent') as delete:
            out = engine.clean(preview, self.policy, 'permanent', authorized=True, lock_dir=self.lock)
        delete.assert_not_called()
        self.assertEqual(out.skipped, 1)

    def test_replaced_parent_symlink_is_rejected(self):
        folder = self.root / 'nested'
        victim = self.file(folder / 'file')
        preview = self.preview()
        victim.unlink()
        folder.rmdir()
        self.file(self.outside / 'file')
        self.symlink(self.outside, folder, directory=True)
        seen = []
        with patch('cleanflow.engine.native.permanent', side_effect=lambda c, p, t: seen.append(c.path) or c.size):
            out = engine.clean(preview, self.policy, 'permanent', authorized=True, lock_dir=self.lock)
        self.assertNotIn(victim, seen)
        self.assertTrue((self.outside / 'file').exists())
        self.assertEqual(out.skipped, 1)

    def test_cancelled_scan_cannot_clean(self):
        cancel = threading.Event()
        cancel.set()
        preview = engine.scan(self.policy, {'user_temp'}, cancel)
        self.assertTrue(preview.cancelled)
        with self.assertRaises(ValueError):
            engine.clean(preview, self.policy, lock_dir=self.lock)

    def test_cancel_cleanup_and_separate_errors(self):
        cancel = threading.Event()
        cancel.set()
        with patch('cleanflow.engine.native.permanent') as delete:
            out = engine.clean(self.preview(), self.policy, 'permanent', authorized=True, cancel=cancel, lock_dir=self.lock)
        delete.assert_not_called()
        self.assertTrue(out.cancelled)
        self.assertEqual(out.skipped, 1)
        with patch('cleanflow.engine.native.permanent', side_effect=PermissionError('locked')):
            out = engine.clean(self.preview(), self.policy, 'permanent', authorized=True, lock_dir=self.lock)
            self.assertEqual((out.skipped, out.failed), (1, 0))
        with patch('cleanflow.engine.native.permanent', side_effect=OSError('I/O error')):
            out = engine.clean(self.preview(), self.policy, 'permanent', authorized=True, lock_dir=self.lock)
            self.assertEqual((out.skipped, out.failed), (0, 1))

    def test_forged_outside_candidate_cannot_reach_backend(self):
        preview = self.preview()
        secret = self.file(self.outside / 'secret')
        st = secret.stat()
        preview.candidates.append(Candidate(secret, self.policy.roots[0], st.st_size, st.st_mtime_ns,
                                            st.st_ctime_ns, st.st_dev, st.st_ino))
        called = []
        with patch('cleanflow.engine.native.permanent', side_effect=lambda c, p, t: called.append(c.path) or c.size):
            out = engine.clean(preview, self.policy, 'permanent', authorized=True, lock_dir=self.lock)
        self.assertEqual(called, [self.old])
        self.assertEqual((out.cleaned, out.skipped), (1, 1))
        self.assertTrue(secret.exists())
        self.assertTrue(self.root.exists())

    def test_prefetch_manual_confirmation_and_schedule_ban(self):
        pf = Root(self.root, 'prefetch')
        policy = Policy([pf])
        preview = engine.scan(policy, {'prefetch'})
        out = engine.clean(preview, policy, lock_dir=self.lock)
        self.assertEqual((out.previewed, out.skipped), (0, 1))
        out = engine.clean(preview, policy, prefetch_authorized=True, lock_dir=self.lock)
        self.assertEqual(out.previewed, 1)
        scheduled = Policy([pf], scheduled=True)
        self.assertFalse(engine.scan(scheduled, {'prefetch'}).candidates)

    def test_overlapping_roots_deduplicate_files(self):
        nested = self.root / 'sub'
        self.file(nested / 'cache')
        policy = Policy([Root(self.root, 'user_temp'), Root(nested, 'browser'), Root(self.root, 'user_temp')])
        out = engine.scan(policy, {'user_temp', 'browser'})
        self.assertEqual(len(out.candidates), 2)
        self.assertEqual(out.scanned, 2)
        self.assertEqual(out.stats['browser']['eligible'], 1)
        out = engine.scan(policy, {'user_temp'})
        self.assertEqual(len(out.candidates), 1)

    def test_bounded_batch_can_be_rescanned(self):
        for i in range(3):
            self.file(self.root / str(i))
        with patch('cleanflow.engine.MAX_CANDIDATES', 2):
            out = self.preview()
        self.assertEqual(len(out.candidates), 2)
        self.assertTrue(out.truncated)
        self.assertFalse(out.cancelled)

    def test_discovery_rejects_personal_or_arbitrary_temp_overrides(self):
        local = self.base / 'Local'
        profile = self.base / 'User'
        roots = discover({'LOCALAPPDATA': str(local), 'USERPROFILE': str(profile), 'TEMP': str(profile / 'Documents')})
        self.assertEqual([r.path for r in roots if r.category == 'user_temp'], [local / 'Temp'])
        roots = discover({'LOCALAPPDATA': str(profile / 'Documents'), 'USERPROFILE': str(profile)})
        self.assertFalse(roots)
        if os.name != 'nt':
            self.assertEqual(discover(), [])

    def test_scan_file_limit_applies_to_fresh_files(self):
        self.old.unlink()
        for i in range(5):
            self.file(self.root / str(i), days=1)
        with patch('cleanflow.engine.MAX_SCANNED', 2):
            out = self.preview()
        self.assertTrue(out.truncated)
        self.assertEqual(out.scanned, 2)
        self.assertFalse(out.candidates)

    def test_protected_and_reparse_attribute_detection(self):
        from types import SimpleNamespace
        from cleanflow.policy import reparse
        self.assertTrue(reparse(SimpleNamespace(st_mode=0, st_file_attributes=0x400)))
        self.assertFalse(reparse(SimpleNamespace(st_mode=stat_mode(), st_file_attributes=0)))


def stat_mode():
    import stat
    return stat.S_IFREG | 0o600

if __name__ == '__main__':
    unittest.main()
