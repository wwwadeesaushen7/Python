@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 goto folder_error
title CleanFlow PC - Build
set "BUILD_LOG=%~dp0build.log"
> "%BUILD_LOG%" echo CleanFlow PC build started %date% %time%
if errorlevel 1 goto folder_error

echo CleanFlow PC - Windows build
echo This builds and then opens the app. No administrator access is required.
echo Full output is saved to build.log in this folder.
echo.

where py >nul 2>&1
if errorlevel 1 goto try_python
py -3.12 -c "import sys; sys.exit(sys.version_info[:2] != (3,12))" >nul 2>&1
if errorlevel 1 goto try_default_launcher
set "PY_COMMAND=py -3.12"
goto python_ready

:try_default_launcher
py -3 -c "import sys; sys.exit(sys.version_info < (3,10))" >nul 2>&1
if errorlevel 1 goto try_python
set "PY_COMMAND=py -3"
goto python_ready

:try_python
python -c "import sys; sys.exit(sys.version_info < (3,10))" >nul 2>&1
if errorlevel 1 goto no_python
set "PY_COMMAND=python"

:python_ready
echo [1/5] Creating the local Python environment...
%PY_COMMAND% -m venv .venv >> "%BUILD_LOG%" 2>&1
if errorlevel 1 goto failed

echo [2/5] Checking Tkinter...
".venv\Scripts\python.exe" -c "import tkinter; print('Tkinter:', tkinter.TkVersion)" >> "%BUILD_LOG%" 2>&1
if errorlevel 1 goto tkinter_error

echo [3/5] Installing build tools - internet needed for this step...
".venv\Scripts\python.exe" -m pip install -r requirements-build.txt >> "%BUILD_LOG%" 2>&1
if errorlevel 1 goto failed

echo [4/5] Running disposable-folder safety tests...
".venv\Scripts\python.exe" -m unittest discover -s tests -v >> "%BUILD_LOG%" 2>&1
if errorlevel 1 goto failed

echo [5/5] Building the executable - this may take a few minutes...
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean CleanFlowPC.spec >> "%BUILD_LOG%" 2>&1
if errorlevel 1 goto failed
if not exist "dist\CleanFlowPC\CleanFlowPC.exe" goto missing_exe

echo.
echo BUILD SUCCESSFUL
echo Opening dist\CleanFlowPC\CleanFlowPC.exe ...
echo Keep the entire dist\CleanFlowPC folder together when moving the app.
start "" "%~dp0dist\CleanFlowPC\CleanFlowPC.exe"
echo.
pause
exit /b 0

:no_python
echo ERROR: Python 3.10 or newer was not found.
echo Install Python 3.12 from python.org with Tcl/Tk and the Python launcher.
echo Then reopen this file. You can install Python just for your user account.
echo Python 3.10 or newer was not found. >> "%BUILD_LOG%"
pause
exit /b 1

:tkinter_error
echo ERROR: Tkinter is missing. Modify your Python installation and add Tcl/Tk.
goto failed

:missing_exe
echo ERROR: PyInstaller did not produce the expected executable. >> "%BUILD_LOG%"
goto failed

:failed
echo.
echo BUILD STOPPED. The error output follows:
echo.
type "%BUILD_LOG%"
echo.
echo Save or copy the last error lines from build.log so the problem can be diagnosed.
echo The window will stay open until you press a key.
pause
exit /b 1

:folder_error
echo ERROR: This folder cannot be opened or written to.
echo Extract the entire ZIP to a normal folder you can write to, then try again.
pause
exit /b 1
