"""Tk widgets stay on the main thread; workers communicate through a bounded queue."""
import datetime as dt
import os
from pathlib import Path
import queue
import shutil
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from . import __version__, engine
from .models import CATEGORIES
from .paths import discover
from .policy import Policy
from .storage import Settings, History
from .scheduler import Scheduler, approval, startup


def size(n):
    n = float(n)
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if abs(n) < 1024 or unit == 'TB':
            return f'{n:,.1f} {unit}'
        n /= 1024


def date(n):
    return dt.datetime.fromtimestamp(n).strftime('%d %b %Y · %H:%M') if n else 'No cleanup yet'


class App(tk.Tk):
    def __init__(self, settings=None, history=None):
        super().__init__()
        self.title('CleanFlow PC')
        self.geometry('1180x800')
        self.minsize(1000, 740)
        self.settings = settings or Settings()
        self.history = history or History()
        self.roots = discover()
        self.preview = None
        self.preview_policy = None
        self.last_result = None
        self.busy = False
        self.closing = False
        self.cancel = threading.Event()
        self.events = queue.Queue(maxsize=128)
        self.page = 'Dashboard'
        self.category_vars = {c: tk.BooleanVar(value=c == 'user_temp') for c in CATEGORIES}
        self.mode = tk.StringVar(value='dry-run')
        self.status = tk.StringVar(value='Ready · Nothing is cleaned until you authorize it.')
        self.apply_theme()
        self.build_shell()
        self.show('Dashboard')
        self.set_controls(True)
        self.after(80, self.poll)
        self.protocol('WM_DELETE_WINDOW', self.close)
        if self.settings.warning:
            self.after(300, lambda: messagebox.showwarning('Settings', self.settings.warning))

    def apply_theme(self):
        dark = self.settings.values['theme'] == 'dark'
        self.colors = dict(bg='#0c1220' if dark else '#eef2f8', panel='#151e30' if dark else '#ffffff',
                           text='#edf3ff' if dark else '#17243b', muted='#9caec9' if dark else '#536681',
                           edge='#28364e' if dark else '#d6deeb', blue='#4389ff', field='#101a2b' if dark else '#f4f7fc')
        c = self.colors
        self.configure(bg=c['bg'])
        from tkinter import font
        self.font_family = 'Segoe UI' if os.name == 'nt' else 'Arial'
        self.bold_family = 'Segoe UI Semibold' if os.name == 'nt' else 'Arial'
        font.nametofont('TkDefaultFont').configure(family=self.font_family, size=10)
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('.', background=c['bg'], foreground=c['text'], font=(self.font_family, 10))
        style.configure('TFrame', background=c['bg'])
        style.configure('Card.TFrame', background=c['panel'], relief='flat')
        style.configure('TLabel', background=c['bg'], foreground=c['text'])
        style.configure('Muted.TLabel', foreground=c['muted'])
        style.configure('Card.TLabel', background=c['panel'])
        style.configure('Metric.TLabel', background=c['panel'], font=(self.bold_family, 24, 'bold'))
        style.configure('Title.TLabel', font=(self.bold_family, 25, 'bold'))
        style.configure('Subtitle.TLabel', font=(self.bold_family, 13, 'bold'))
        style.configure('TButton', background=c['edge'], foreground=c['text'], padding=(15, 9), borderwidth=0)
        style.map('TButton', background=[('active', '#315077'), ('disabled', c['panel'])],
                  foreground=[('disabled', c['muted'])])
        style.configure('Accent.TButton', background=c['blue'], foreground='white')
        style.map('Accent.TButton', background=[('active', '#2876ed'), ('disabled', c['edge'])])
        style.configure('Nav.TButton', anchor='w', padding=(18, 13), background=c['panel'])
        style.configure('Active.Nav.TButton', background='#244475' if dark else '#d8e7ff', foreground=c['text'])
        style.configure('TCheckbutton', background=c['bg'], foreground=c['text'], padding=4)
        style.map('TCheckbutton', background=[('active', c['bg'])])
        style.configure('TRadiobutton', background=c['bg'], foreground=c['text'], padding=4)
        style.map('TRadiobutton', background=[('active', c['bg'])])
        style.configure('TEntry', fieldbackground=c['field'], foreground=c['text'], insertcolor=c['text'], padding=7)
        style.configure('TCombobox', fieldbackground=c['field'], foreground=c['text'], padding=7)
        style.map('TCombobox', fieldbackground=[('readonly', c['field'])], foreground=[('readonly', c['text'])])
        style.configure('Treeview', background=c['panel'], fieldbackground=c['panel'], foreground=c['text'],
                        rowheight=30, borderwidth=0)
        style.configure('Treeview.Heading', background=c['edge'], foreground=c['text'], padding=8)
        style.map('Treeview', background=[('selected', '#2459a3')], foreground=[('selected', 'white')])
        style.configure('Horizontal.TProgressbar', troughcolor=c['edge'], background=c['blue'], borderwidth=0)

    def build_shell(self):
        self.sidebar = ttk.Frame(self, style='Card.TFrame', padding=(16, 26), width=228)
        self.sidebar.pack(side='left', fill='y')
        self.sidebar.pack_propagate(False)
        ttk.Label(self.sidebar, text='◈  CleanFlow', style='Card.TLabel', font=(self.bold_family, 20, 'bold')).pack(anchor='w')
        ttk.Label(self.sidebar, text='PC CARE, WITH CONTROL', style='Card.TLabel', foreground=self.colors['muted'],
                  font=(self.font_family, 8)).pack(anchor='w', pady=(5, 30))
        self.nav = {}
        for name in ('Dashboard', 'Junk Scanner', 'Clean Files', 'Automatic Cleaning', 'Cleaning History', 'Settings'):
            button = ttk.Button(self.sidebar, text=name, style='Nav.TButton', command=lambda n=name: self.show(n))
            button.pack(fill='x', pady=3)
            self.nav[name] = button
        ttk.Label(self.sidebar, text=f'LOCAL & OFFLINE\nv{__version__}\n\nNo accounts. No telemetry.', style='Card.TLabel',
                  foreground=self.colors['muted'], justify='left').pack(side='bottom', anchor='w')
        outer = ttk.Frame(self, padding=(28, 24))
        outer.pack(fill='both', expand=True)
        self.content = ttk.Frame(outer)
        self.content.pack(fill='both', expand=True)
        self.progress = ttk.Progressbar(outer, mode='determinate')
        self.progress.pack(fill='x', pady=(12, 8))
        ttk.Label(outer, textvariable=self.status, style='Muted.TLabel', wraplength=850).pack(anchor='w')

    def heading(self, title, subtitle):
        ttk.Label(self.content, text=title, style='Title.TLabel').pack(anchor='w')
        ttk.Label(self.content, text=subtitle, style='Muted.TLabel', wraplength=850).pack(anchor='w', pady=(6, 22))

    def show(self, name):
        self.page = name
        for child in self.content.winfo_children():
            child.destroy()
        for n, button in self.nav.items():
            button.configure(style='Active.Nav.TButton' if n == name else 'Nav.TButton')
        {'Dashboard': self.dashboard, 'Junk Scanner': self.scanner, 'Clean Files': self.clean_page,
         'Automatic Cleaning': self.automatic, 'Cleaning History': self.history_page, 'Settings': self.preferences}[name]()
        if self.busy:
            self.set_controls(False)

    def card(self, parent, title, value, detail=''):
        card = ttk.Frame(parent, style='Card.TFrame', padding=18)
        ttk.Label(card, text=title, style='Card.TLabel', foreground=self.colors['muted']).pack(anchor='w')
        ttk.Label(card, text=value, style='Metric.TLabel').pack(anchor='w', pady=8)
        if detail:
            ttk.Label(card, text=detail, style='Card.TLabel', foreground=self.colors['muted']).pack(anchor='w')
        return card

    def action_row(self, parent=None):
        row = ttk.Frame(parent or self.content)
        row.pack(fill='x', pady=16)
        ttk.Button(row, text='Scan Now', style='Accent.TButton', command=self.start_scan).pack(side='left', padx=(0, 8))
        ttk.Button(row, text='Clean Selected', command=lambda: self.show('Clean Files')).pack(side='left', padx=8)
        ttk.Button(row, text='View Details', command=self.details).pack(side='left', padx=8)
        stop = ttk.Button(row, text='Stop Scan' if self.page != 'Clean Files' else 'Stop Job', command=self.stop)
        stop.pack(side='right')
        return row

    def dashboard(self):
        self.heading('A little room to breathe.', 'Review your storage. Choose what to clean. Stay in control.')
        try:
            disk = shutil.disk_usage(Path(os.environ.get('SystemRoot', str(Path.home()))).anchor)
        except OSError:
            disk = shutil.disk_usage(Path.home())
        metrics = ttk.Frame(self.content)
        metrics.pack(fill='x')
        for i, (label, value) in enumerate((('Disk capacity', size(disk.total)), ('Used storage', size(disk.used)),
                                           ('Available', size(disk.free)))):
            self.card(metrics, label, value).grid(row=0, column=i, sticky='nsew', padx=(0 if i == 0 else 10, 0))
            metrics.columnconfigure(i, weight=1)
        usage = ttk.Frame(self.content, style='Card.TFrame', padding=20)
        usage.pack(fill='x', pady=16)
        pct = disk.used / disk.total * 100 if disk.total else 0
        ttk.Label(usage, text=f'Storage usage  ·  {pct:.1f}%', style='Card.TLabel').pack(anchor='w', pady=(0, 12))
        ttk.Progressbar(usage, value=pct, maximum=100).pack(fill='x')
        junk = sum(s['reclaimable'] for s in self.preview.stats.values()) if self.preview else None
        self.card(self.content, 'Estimated eligible junk', size(junk) if junk is not None else 'Scan to find out',
                  'Estimate before open-file and permission checks. No CPU or RAM performance claims.').pack(fill='x')
        self.action_row()
        rows = [r for r in self.history.rows() if r['mode'] != 'dry-run']
        if rows:
            last = rows[0]
            last_text = f"{date(last['started'])} · {last['cleaned']} cleaned · {last['skipped']} skipped · {last['failed']} failed"
        else:
            last_text = 'No cleanup yet'
        ttk.Label(self.content, text='Last cleanup', style='Subtitle.TLabel').pack(anchor='w', pady=(15, 8))
        ttk.Label(self.content, text=last_text, style='Muted.TLabel', wraplength=850).pack(anchor='w')
        ttk.Label(self.content, text='Automatic cleaning  ·  ' + ('ON' if self.settings.values['automatic'] else 'OFF'),
                  style='Muted.TLabel').pack(anchor='w', pady=12)

    def scanner(self):
        self.heading('Junk Scanner', 'Select categories, then scan. Only user temporary files are selected by default.')
        categories = ttk.Frame(self.content)
        categories.pack(fill='x')
        for c, (label, detail) in CATEGORIES.items():
            row = ttk.Frame(categories)
            row.pack(fill='x', pady=2)
            ttk.Checkbutton(row, text=label, variable=self.category_vars[c], command=self.invalidate, width=26).pack(side='left')
            ttk.Label(row, text=detail, style='Muted.TLabel', wraplength=565).pack(side='left', padx=8)
        self.action_row()
        self.stats_tree = self.tree(self.content, ('Category', 'Files', 'Total size', 'Eligible', 'Estimate'), height=6,
                                    widths=(260, 85, 115, 85, 115))
        if self.preview:
            for c, s in self.preview.stats.items():
                self.stats_tree.insert('', 'end', values=(CATEGORIES[c][0], s['files'], size(s['bytes']), s['eligible'], size(s['reclaimable'])))
        ttk.Label(self.content, text='Recycle Bin is inspected through Windows, read only. Prefetch cleanup is optional and manual only.',
                  style='Muted.TLabel', wraplength=850).pack(anchor='w', pady=12)

    def invalidate(self):
        self.preview = None
        self.preview_policy = None
        self.status.set('Selection or rules changed. Scan again before cleanup.')

    def tree(self, parent, columns, height=8, widths=None):
        box = ttk.Frame(parent)
        box.pack(fill='both', expand=True)
        tree = ttk.Treeview(box, columns=columns, show='headings', height=height)
        for i, col in enumerate(columns):
            tree.heading(col, text=col)
            tree.column(col, width=widths[i] if widths else 120, minwidth=60, stretch=True)
        scroll = ttk.Scrollbar(box, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        tree.pack(fill='both', expand=True)
        return tree

    def clean_page(self):
        self.heading('Clean Files', 'Preview first. Every file is checked again immediately before cleanup.')
        count = len(self.preview.candidates) if self.preview else 0
        total = sum(c.size for c in self.preview.candidates) if self.preview else 0
        self.card(self.content, 'Eligible in the latest scan', f'{count:,} files · {size(total)}',
                  'No folders are removed. Locked, changed or inaccessible files are skipped.').pack(fill='x')
        choices = (
            ('dry-run', 'Dry-run preview — verify eligibility without deleting anything'),
            ('recycle', 'Move to Recycle Bin — recoverable; disk space is not immediately freed'),
            ('permanent', 'Permanently delete — cannot be undone; explicit confirmation required'),
        )
        for value, label in choices:
            ttk.Radiobutton(self.content, text=label, variable=self.mode, value=value).pack(anchor='w', pady=6)
        row = ttk.Frame(self.content)
        row.pack(fill='x', pady=16)
        ttk.Button(row, text='Clean Selected', style='Accent.TButton', command=self.start_clean).pack(side='left')
        ttk.Button(row, text='View Details', command=self.details).pack(side='left', padx=12)
        ttk.Button(row, text='Stop Job', command=self.stop).pack(side='right')
        if not self.preview:
            ttk.Label(self.content, text='Complete a scan to enable a cleanup preview.', style='Muted.TLabel').pack(anchor='w', pady=10)
        if self.last_result:
            r = self.last_result
            text = (f'Files scanned: {r.scanned:,}     Cleaned: {r.cleaned:,}     Skipped: {r.skipped:,}     Failed: {r.failed:,}\n'
                    f'Bytes permanently freed*: {size(r.freed)}     Moved to Recycle Bin: {size(r.recycled)}\n'
                    f'Dry-run verified: {r.previewed:,}     Duration: {r.duration:.2f}s' + ('     Cancelled' if r.cancelled else '') +
                    '\n*Conservative file allocation estimate; actual volume free space can change independently.')
            ttk.Label(self.content, text='Latest result', style='Subtitle.TLabel').pack(anchor='w', pady=(10, 8))
            ttk.Label(self.content, text=text, wraplength=850).pack(anchor='w')

    def current_policy(self):
        return Policy(self.roots, self.settings.values['days'], self.settings.values['exclusions'])

    def start_scan(self):
        if self.busy:
            return
        categories = {c for c, value in self.category_vars.items() if value.get()}
        if not categories:
            messagebox.showinfo('Select a category', 'Choose at least one category in Junk Scanner.')
            self.show('Junk Scanner')
            return
        self.roots = discover()
        policy = self.current_policy()
        self.preview = None
        self.preview_policy = policy
        self.launch('scan', lambda: engine.scan(policy, categories, self.cancel, self.report_progress))

    def start_clean(self):
        if self.busy:
            return
        if not self.preview or self.preview.cancelled or not self.preview.candidates:
            messagebox.showinfo('Scan required', 'Complete a scan with eligible files before cleaning.')
            return
        mode = self.mode.get()
        count = len(self.preview.candidates)
        prefetch = any(c.root.category == 'prefetch' for c in self.preview.candidates)
        pf_authorized = False
        if prefetch:
            pf_authorized = messagebox.askyesno('Prefetch warning',
                'Prefetch improves application launch performance. Removing it can slow subsequent launches.\n\n'
                'Allow Prefetch in this manual operation?', default='no')
            if not pf_authorized:
                return
        if mode != 'dry-run':
            warning = (f'Permanently delete up to {count:,} verified files? This cannot be undone.\n\n'
                       if mode == 'permanent' else f'Move up to {count:,} files to the Recycle Bin?\n\nThis will not immediately free disk space.\n\n')
            if not messagebox.askyesno('Authorize cleanup', warning + 'Files will be rechecked. In-use and changed files are skipped.', default='no'):
                return
        preview, policy = self.preview, self.preview_policy
        self.launch('clean', lambda: engine.clean(preview, policy, mode, authorized=mode != 'dry-run',
                    prefetch_authorized=pf_authorized, cancel=self.cancel, progress=self.report_progress,
                    lock_dir=self.settings.folder))

    def automatic(self):
        self.heading('Automatic Cleaning', 'Normal user permissions. No full interface opens during scheduled runs.')
        state = 'ON' if self.settings.values['automatic'] else 'OFF · manual cleaning only'
        self.card(self.content, 'Automatic cleaning', state, 'Prefetch, browsers, crash dumps and the Recycle Bin are never included.').pack(fill='x')
        form = ttk.Frame(self.content)
        form.pack(fill='x', pady=18)
        self.freq = tk.StringVar(value=self.settings.values['frequency'])
        self.hour = tk.StringVar(value=self.settings.values['hour'])
        self.schedule_days = tk.StringVar(value=str(self.settings.values['days']))
        for i, (label, var, options) in enumerate((('Frequency', self.freq, ('daily', 'weekly', 'logon')),
                                                  ('Time (24h, local)', self.hour, None), ('Minimum age (days)', self.schedule_days, None))):
            ttk.Label(form, text=label).grid(row=i, column=0, sticky='w', padx=(0, 16), pady=5)
            widget = ttk.Combobox(form, textvariable=var, values=options, state='readonly', width=21) if options else ttk.Entry(form, textvariable=var, width=23)
            widget.grid(row=i, column=1, sticky='w', pady=5)
        ttk.Label(self.content, text='Weekly runs on Mondays. Login runs wait 2 minutes. Your Windows session must be signed in.\n'
                  'The computer is not woken up. Missed calendar runs start when available.', style='Muted.TLabel', wraplength=850).pack(anchor='w')
        row = ttk.Frame(self.content)
        row.pack(fill='x', pady=16)
        for title, action in (('Enable / Change', 'register'), ('Enable existing', 'enable'), ('Disable', 'disable'), ('Delete task', 'delete'), ('Check task', 'status')):
            ttk.Button(row, text=title, command=lambda a=action: self.schedule_action(a)).pack(side='left', padx=(0, 7))
        ttk.Label(self.content, text='Approved scope', style='Subtitle.TLabel').pack(anchor='w', pady=(10, 8))
        roots = [str(r.path) for r in self.roots if r.category == 'user_temp']
        scope = '\n'.join(roots) if roots else 'No Windows user temporary folder is available on this machine.'
        ttk.Label(self.content, text=scope + '\n\nOnly regular, unchanged, unlinked files older than the approved age.\n'
                  'Scheduled cleanup permanently deletes eligible files. No permission prompts or elevation.', wraplength=850,
                  style='Muted.TLabel').pack(anchor='w')

    def schedule_action(self, action):
        if self.busy:
            return
        values = self.settings.values
        if action in ('register', 'enable'):
            try:
                days = int(self.schedule_days.get())
                if not 1 <= days <= 3650:
                    raise ValueError('Age must be 1–3650 days')
                dt.datetime.strptime(self.hour.get(), '%H:%M')
                frequency, hour = self.freq.get(), self.hour.get()
            except ValueError as e:
                messagebox.showerror('Invalid schedule', str(e))
                return
        else:
            days, frequency, hour = values['days'], values['frequency'], values['hour']
        roots = [r for r in discover() if r.category == 'user_temp']
        approved = approval(roots, days, values['exclusions'])
        if action in ('register', 'enable'):
            if not roots:
                messagebox.showerror('No approved folders', 'Scheduling requires a Windows user temporary folder.')
                return
            if action == 'enable' and approved != values['schedule_approval']:
                messagebox.showinfo('Approval changed', 'Use Enable / Change to register the current folders and retention rules.')
                return
            if action == 'enable':
                frequency, hour = values['frequency'], values['hour']
            text = ('Permanently delete regular, verified user temporary files with modification age of at least '
                    f'{days} days. This cannot be undone.\n\nFolders:\n' + '\n'.join(approved['roots']) +
                    '\n\nExclusions:\n' + ('\n'.join(approved['exclusions']) or '(none)') +
                    f'\n\nFrequency: {frequency}; local time: {hour} (ignored at login).\n'
                    'Links, in-use files and protected files are skipped. No Prefetch or other categories.\n\nEnable this schedule?')
            if not messagebox.askyesno('Authorize automatic permanent cleanup', text, default='no'):
                return
        elif action == 'delete' and not messagebox.askyesno('Delete scheduled task', 'Delete the CleanFlow PC task for this Windows user?', default='no'):
            return
        # Persist OFF first so a failed registration/disable cannot authorize cleanup.
        if action != 'status':
            values['automatic'] = False
            self.settings.save()
        def work():
            scheduler = Scheduler()
            if action == 'register':
                scheduler.register(frequency, hour)
                return action, approved, frequency, hour
            getattr(scheduler, action)()
            return action, approved, frequency, hour
        if action == 'status':
            self.launch('schedule-status', lambda: Scheduler().status())
        else:
            self.launch('schedule', work)

    def history_page(self):
        self.heading('Cleaning History', 'The last 200 operations, stored locally. No filenames or file contents are recorded.')
        tree = self.tree(self.content, ('Date', 'Mode', 'Scanned', 'Cleaned', 'Skipped', 'Failed', 'Freed*', 'Recycled', 'Seconds'),
                         widths=(165, 95, 70, 70, 70, 60, 80, 80, 65))
        for r in self.history.rows():
            tree.insert('', 'end', values=(date(r['started']), r['mode'], r['scanned'], r['cleaned'], r['skipped'], r['failed'],
                                           size(r['freed']), size(r['recycled']), f"{r['duration']:.1f}"))
        ttk.Label(self.content, text='*Conservative allocation estimate. Recycled bytes do not count as freed space.', style='Muted.TLabel').pack(anchor='w', pady=12)

    def preferences(self):
        self.heading('Settings', 'Local preferences. Changes to retention or exclusions require fresh schedule approval.')
        v = self.settings.values
        self.theme_var = tk.StringVar(value=v['theme'])
        self.age_var = tk.StringVar(value=str(v['days']))
        self.notify_var = tk.BooleanVar(value=v['notifications'])
        self.startup_var = tk.BooleanVar(value=v['startup'])
        row = ttk.Frame(self.content)
        row.pack(fill='x')
        ttk.Label(row, text='Appearance', width=23).grid(row=0, column=0, sticky='w', pady=8)
        ttk.Combobox(row, textvariable=self.theme_var, values=('dark', 'light'), state='readonly', width=20).grid(row=0, column=1)
        ttk.Label(row, text='Minimum file age (days)', width=23).grid(row=1, column=0, sticky='w', pady=8)
        ttk.Entry(row, textvariable=self.age_var, width=22).grid(row=1, column=1)
        ttk.Checkbutton(self.content, text='Completion notifications (dialog in app; sound for scheduled jobs)', variable=self.notify_var).pack(anchor='w', pady=10)
        ttk.Checkbutton(self.content, text='Open CleanFlow PC after Windows login (does not start cleanup)', variable=self.startup_var).pack(anchor='w', pady=4)
        ttk.Label(self.content, text='Permanent deletion always requires confirmation. Scheduled runs use separate explicit approval.',
                  style='Muted.TLabel', wraplength=850).pack(anchor='w', pady=8)
        ttk.Label(self.content, text='Scan exclusions · one absolute folder or file path per line', style='Subtitle.TLabel').pack(anchor='w', pady=(15, 8))
        self.exclusion_text = tk.Text(self.content, height=6, bg=self.colors['field'], fg=self.colors['text'],
                                      insertbackground=self.colors['text'], relief='flat', padx=12, pady=12,
                                      font=('Consolas', 10), undo=True)
        self.exclusion_text.insert('1.0', '\n'.join(v['exclusions']))
        self.exclusion_text.pack(fill='x')
        ttk.Button(self.content, text='Save preferences', style='Accent.TButton', command=self.save_preferences).pack(anchor='w', pady=18)
        ttk.Button(self.content, text='Manage automatic cleaning', command=lambda: self.show('Automatic Cleaning')).pack(anchor='w')

    def save_preferences(self):
        if self.busy:
            return
        try:
            age = int(self.age_var.get())
            if not 1 <= age <= 3650:
                raise ValueError('Age must be 1–3650 days')
            exclusions = [line.strip() for line in self.exclusion_text.get('1.0', 'end').splitlines() if line.strip()]
            if not all(Path(p).is_absolute() for p in exclusions):
                raise ValueError('Exclusions must be absolute paths')
            v = self.settings.values
            changed_rules = age != v['days'] or exclusions != v['exclusions']
            if self.startup_var.get() != v['startup']:
                startup(self.startup_var.get())
            if changed_rules:
                v['automatic'] = False
                v['schedule_approval'] = None
            v.update(theme=self.theme_var.get(), days=age, exclusions=exclusions,
                     notifications=self.notify_var.get(), startup=self.startup_var.get())
            self.settings.save()
            self.invalidate()
            self.apply_theme()
            # Rebuild the shell so all plain Tk widgets pick up the new palette.
            self.sidebar.destroy()
            self.content.master.destroy()
            self.build_shell()
            self.show('Settings')
            self.status.set('Preferences saved.' + (' Automatic cleaning is off; reapprove its rules to enable.' if changed_rules else ''))
        except (ValueError, OSError) as e:
            messagebox.showerror('Preferences not saved', str(e))

    def details(self):
        win = tk.Toplevel(self)
        win.title('CleanFlow PC · Operation details')
        win.geometry('1050x650')
        win.configure(bg=self.colors['bg'])
        ttk.Label(win, text='Paths below stay in this session. Only aggregate results are saved.', padding=15).pack(anchor='w')
        notebook = ttk.Notebook(win)
        notebook.pack(fill='both', expand=True, padx=15, pady=12)
        rows = self.last_result.details if self.last_result else (self.preview.details if self.preview else [])
        for kind in ('Eligible', 'Skipped', 'Failed'):
            frame = ttk.Frame(notebook)
            notebook.add(frame, text=kind)
            tree = self.tree(frame, ('Path', 'Details'), height=15, widths=(650, 350))
            entries = [(str(c.path), size(c.size)) for c in self.preview.candidates[:1000]] if kind == 'Eligible' and self.preview else [
                (path, reason) for k, path, reason in rows if k == kind]
            for entry in entries:
                tree.insert('', 'end', values=entry)
        ttk.Label(win, text='Displays up to 1,000 eligible paths and 1,000 diagnostics. Totals include the full processed batch.', padding=15).pack(anchor='w')
        ttk.Button(win, text='Open Windows Recycle Bin', command=self.open_bin).pack(anchor='w', padx=15, pady=(0, 12))

    def open_bin(self):
        try:
            from .native import require_windows
            require_windows()
            os.startfile('shell:RecycleBinFolder')
        except OSError as e:
            messagebox.showerror('Recycle Bin', str(e))

    def report_progress(self, current, total):
        try:
            self.events.put_nowait(('progress', (current, total)))
        except queue.Full:
            pass

    def launch(self, kind, callback):
        if self.busy:
            return
        self.busy = True
        self.cancel.clear()
        self.set_controls(False)
        self.progress.configure(mode='indeterminate')
        self.progress.start(12)
        self.status.set('Scanning…' if kind == 'scan' else 'Working…')
        def work():
            try:
                self.events.put((kind, callback()))
            except Exception as e:
                self.events.put(('error', str(e)))
        threading.Thread(target=work, name='CleanFlow-worker', daemon=True).start()

    def set_controls(self, enabled):
        def visit(widget):
            for child in widget.winfo_children():
                if isinstance(child, (ttk.Button, ttk.Checkbutton, ttk.Radiobutton, ttk.Entry, ttk.Combobox)):
                    is_stop = isinstance(child, ttk.Button) and child.cget('text') in ('Stop Scan', 'Stop Job')
                    if is_stop:
                        child.state(['!disabled'] if self.busy else ['disabled'])
                    else:
                        child.state(['!disabled'] if enabled else ['disabled'])
                visit(child)
        visit(self.content)

    def stop(self):
        if self.busy:
            self.cancel.set()
            self.status.set('Stopping after the current file…')

    def poll(self):
        try:
            for _ in range(100):
                kind, value = self.events.get_nowait()
                if kind == 'progress':
                    self.status.set(f'Working · {value[0]:,} processed · {value[1]:,} eligible / total')
                    continue
                self.busy = False
                self.progress.stop()
                self.progress.configure(mode='determinate', value=0)
                self.set_controls(True)
                if kind == 'scan':
                    self.preview = value
                    self.last_result = None
                    self.status.set(f'Scan {"cancelled" if value.cancelled else "complete"} · {value.scanned:,} files · '
                                    f'{len(value.candidates):,} eligible · {value.skipped:,} skipped · {value.failed:,} failed · {value.duration:.1f}s' +
                                    (' · Batch limit reached; clean and rescan.' if value.truncated else ''))
                    self.show('Junk Scanner')
                elif kind == 'clean':
                    self.last_result = value
                    try:
                        self.history.add(value)
                    except Exception as e:
                        messagebox.showwarning('History could not be saved', str(e))
                    if value.mode != 'dry-run':
                        self.preview = None
                    self.status.set('Cleanup cancelled.' if value.cancelled else 'Operation complete. Review the result and details.')
                    self.show('Clean Files')
                    if self.settings.values['notifications'] and not self.closing:
                        messagebox.showinfo('CleanFlow PC', f'{value.cleaned:,} cleaned · {value.skipped:,} skipped · {value.failed:,} failed\n'
                                               f'{value.previewed:,} verified in dry-run · {value.duration:.2f}s')
                elif kind == 'schedule':
                    action, approved, frequency, hour = value
                    if action in ('register', 'enable'):
                        self.settings.values.update(automatic=True, schedule_approval=approved, days=approved['days'], frequency=frequency, hour=hour)
                        self.invalidate()
                    else:
                        self.settings.values['automatic'] = False
                    if action == 'delete':
                        self.settings.values['schedule_approval'] = None
                    self.settings.save()
                    self.status.set('Scheduled task updated: ' + action)
                    self.show('Automatic Cleaning')
                elif kind == 'schedule-status':
                    self.status.set('Windows task: ' + value + ' · Local automatic approval: ' + ('ON' if self.settings.values['automatic'] else 'OFF'))
                elif kind == 'error':
                    self.status.set('Operation stopped. ' + value)
                    if not self.closing:
                        messagebox.showerror('CleanFlow PC', value)
        except queue.Empty:
            pass
        except Exception as error:
            self.busy = False
            self.progress.stop()
            self.set_controls(True)
            self.settings.values['automatic'] = False
            self.status.set('Could not save or display the operation result: ' + str(error))
            if not self.closing:
                messagebox.showerror('CleanFlow PC', str(error))
        if self.closing and not self.busy:
            self.destroy()
            return
        self.after(80, self.poll)

    def close(self):
        if self.busy:
            self.closing = True
            self.stop()
        else:
            self.destroy()
