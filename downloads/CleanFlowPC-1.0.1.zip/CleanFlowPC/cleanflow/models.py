from dataclasses import dataclass, field
from pathlib import Path
import time

CATEGORIES = {
    'user_temp': ('User temporary files', 'Only allowlisted user temp files; selected by default.'),
    'system_temp': ('Windows temporary files', 'Optional; inaccessible files are skipped. No elevation.'),
    'browser': ('Browser caches', 'Chrome, Edge and Firefox cache folders only. Close browsers yourself first.'),
    'crash': ('Crash dumps', 'Optional diagnostic dumps; removing them may hinder troubleshooting.'),
    'prefetch': ('Prefetch', 'Helps Windows launch apps faster. Manual only; removal can slow launches.'),
    'recycle': ('Recycle Bin', 'Read-only size query. Empty it in Windows after reviewing its contents.'),
}

@dataclass(frozen=True)
class Root:
    path: Path
    category: str

@dataclass(frozen=True)
class Candidate:
    path: Path
    root: Root
    size: int
    mtime_ns: int
    ctime_ns: int
    device: int
    inode: int
    change_token: int = 0

@dataclass
class Scan:
    started: float = field(default_factory=time.time)
    candidates: list = field(default_factory=list)
    stats: dict = field(default_factory=dict)
    scanned: int = 0
    skipped: int = 0
    failed: int = 0
    details: list = field(default_factory=list)
    cancelled: bool = False
    truncated: bool = False
    duration: float = 0.0

    def note(self, kind, path, reason):
        # Bounded UI diagnostics: totals remain exact, paths are not persisted.
        if len(self.details) < 1000:
            self.details.append((kind, str(path), reason))

@dataclass
class Result:
    started: float = field(default_factory=time.time)
    scanned: int = 0
    cleaned: int = 0
    skipped: int = 0
    failed: int = 0
    freed: int = 0
    recycled: int = 0
    previewed: int = 0
    duration: float = 0.0
    cancelled: bool = False
    mode: str = 'dry-run'
    details: list = field(default_factory=list)

    def note(self, kind, path, reason):
        if len(self.details) < 1000:
            self.details.append((kind, str(path), reason))
