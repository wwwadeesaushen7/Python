"""Windows file handles: pin ancestors, reject reparse points, delete by identity.

No recursive deletes, no permission changes, no elevation or shell commands.
"""
import ctypes
import os
from contextlib import contextmanager
from pathlib import Path
from .policy import UnsafeFile


def require_windows():
    if os.name != 'nt':
        raise OSError('This action requires Windows 10 or later')


if os.name == 'nt':
    from ctypes import wintypes as w
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    class Info(ctypes.Structure):
        _fields_ = [('attrs', w.DWORD), ('created', w.FILETIME), ('access', w.FILETIME),
                    ('written', w.FILETIME), ('volume', w.DWORD), ('high', w.DWORD),
                    ('low', w.DWORD), ('links', w.DWORD), ('index_high', w.DWORD), ('index_low', w.DWORD)]
    class Basic(ctypes.Structure):
        _fields_ = [('created', ctypes.c_longlong), ('accessed', ctypes.c_longlong),
                    ('written', ctypes.c_longlong), ('changed', ctypes.c_longlong), ('attrs', w.DWORD)]
    class Standard(ctypes.Structure):
        _fields_ = [('allocation', ctypes.c_longlong), ('eof', ctypes.c_longlong),
                    ('links', w.DWORD), ('pending', w.BOOLEAN), ('directory', w.BOOLEAN)]
    k.CreateFileW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD, w.LPVOID, w.DWORD, w.DWORD, w.HANDLE]
    k.CreateFileW.restype = w.HANDLE
    k.CloseHandle.argtypes = [w.HANDLE]
    k.GetFileInformationByHandle.argtypes = [w.HANDLE, ctypes.POINTER(Info)]
    k.GetFileInformationByHandleEx.argtypes = [w.HANDLE, ctypes.c_int, w.LPVOID, w.DWORD]
    k.SetFileInformationByHandle.argtypes = [w.HANDLE, ctypes.c_int, w.LPVOID, w.DWORD]
    k.GetFinalPathNameByHandleW.argtypes = [w.HANDLE, w.LPWSTR, w.DWORD, w.DWORD]
    k.GetFinalPathNameByHandleW.restype = w.DWORD


def _open(path, access, share):
    handle = k.CreateFileW(str(path), access, share, None, 3, 0x02200000, None)
    if handle == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    return handle


def _info(handle):
    info = Info()
    if not k.GetFileInformationByHandle(handle, ctypes.byref(info)):
        raise ctypes.WinError(ctypes.get_last_error())
    if info.attrs & 0x400:
        raise UnsafeFile('Reparse point rejected by handle')
    return info


def _final(handle):
    buf = ctypes.create_unicode_buffer(32768)
    n = k.GetFinalPathNameByHandleW(handle, buf, len(buf), 0)
    if not n or n >= len(buf):
        raise OSError('Cannot verify final file path')
    name = buf.value
    if name.startswith('\\\\?\\'):
        name = name[4:]
    return os.path.normcase(os.path.abspath(name))


def _change(handle):
    basic = Basic()
    if not k.GetFileInformationByHandleEx(handle, 0, ctypes.byref(basic), ctypes.sizeof(basic)):
        raise ctypes.WinError(ctypes.get_last_error())
    return basic.changed


def change_token(path, inode):
    require_windows()
    h = _open(path, 0x80, 0x1 | 0x2 | 0x4)
    try:
        info = _info(h)
        if ((info.index_high << 32) | info.index_low) != inode:
            raise UnsafeFile('File changed while scanning')
        return _change(h)
    finally:
        k.CloseHandle(h)


@contextmanager
def guarded(candidate, policy, now):
    """Exclude write/delete sharing on the leaf; pin every parent against renames."""
    require_windows()
    handles = []
    try:
        for parent in reversed(candidate.path.parents):
            h = _open(parent, 0x80, 0x1 | 0x2)  # attributes; no FILE_SHARE_DELETE
            handles.append(h)
            info = _info(h)
            if not info.attrs & 0x10 or _final(h) != os.path.normcase(str(parent)):
                raise UnsafeFile('Ancestor path changed')
        h = _open(candidate.path, 0x10000 | 0x80, 0)  # DELETE + attributes, exclusive
        handles.append(h)
        info = _info(h)
        policy.validate(candidate.path, now, candidate, check_token=False)
        if candidate.change_token and _change(h) != candidate.change_token:
            raise UnsafeFile('File changed since scan (native change time)')
        inode = (info.index_high << 32) | info.index_low
        size = (info.high << 32) | info.low
        if inode != candidate.inode or size != candidate.size or info.links != 1:
            raise UnsafeFile('Handle identity changed')
        if info.attrs & (0x1 | 0x4 | 0x10):
            raise UnsafeFile('Protected file or directory')
        if _final(h) != os.path.normcase(str(candidate.path)):
            raise UnsafeFile('Final path mismatch')
        yield h, handles
    finally:
        for h in reversed(handles):
            k.CloseHandle(h)


def permanent(candidate, policy, now):
    with guarded(candidate, policy, now) as (h, _):
        standard = Standard()
        if not k.GetFileInformationByHandleEx(h, 1, ctypes.byref(standard), ctypes.sizeof(standard)):
            raise ctypes.WinError(ctypes.get_last_error())
        flag = ctypes.c_ubyte(1)
        if not k.SetFileInformationByHandle(h, 4, ctypes.byref(flag), 1):
            raise ctypes.WinError(ctypes.get_last_error())
        return max(0, min(candidate.size, standard.allocation))


def recycle(candidate, policy, now):
    """Queue one verified Shell item; retain all ancestor locks throughout.

The Shell requires releasing the exclusive leaf handle to move the file. Shell
recursion and reparse traversal are disabled; recycle-only mode has no permanent
fallback. Unlike native permanent deletion, this is a path-based Shell operation.
"""
    with guarded(candidate, policy, now) as (handle, handles):
        def release_leaf():
            k.CloseHandle(handle)
            handles.pop()
        _recycle_item(candidate.path, release_leaf)
        if candidate.path.exists():
            raise OSError('Recycle operation did not complete')
        return candidate.size


def recycle_info():
    require_windows()
    class BinInfo(ctypes.Structure):
        _fields_ = [('size', w.DWORD), ('bytes', ctypes.c_longlong), ('items', ctypes.c_longlong)]
    info = BinInfo()
    info.size = ctypes.sizeof(info)
    shell.SHQueryRecycleBinW.argtypes = [w.LPCWSTR, ctypes.POINTER(BinInfo)]
    code = shell.SHQueryRecycleBinW(None, ctypes.byref(info))
    if code != 0:
        raise OSError(f'Recycle Bin query failed ({code:#x})')
    return info.items, info.bytes


def notify(title, message):
    # Standard Windows notification sound for completed background jobs; no UI.
    if os.name == 'nt':
        import winsound
        winsound.MessageBeep(winsound.MB_OK)


# IFileOperation's RECYCLEONDELETE flag (Windows 8+) avoids SHFileOperation's
# possible permanent-delete fallback on volumes without a usable Recycle Bin.
def _recycle_item(path, release_leaf):
    import uuid
    class GUID(ctypes.Structure):
        _fields_ = [('data', ctypes.c_ubyte * 16)]
    def guid(text):
        return GUID((ctypes.c_ubyte * 16).from_buffer_copy(uuid.UUID(text).bytes_le))
    def check(hr):
        if hr < 0:
            raise OSError(f'Windows shell HRESULT 0x{hr & 0xffffffff:08x}')
    def method(obj, slot, restype, *argtypes):
        table = ctypes.cast(obj, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
        return ctypes.WINFUNCTYPE(restype, ctypes.c_void_p, *argtypes)(table[slot])
    ole = ctypes.WinDLL('ole32', use_last_error=True)
    ole.CoInitializeEx.argtypes = [ctypes.c_void_p, w.DWORD]
    ole.CoInitializeEx.restype = ctypes.c_long
    ole.CoCreateInstance.argtypes = [ctypes.POINTER(GUID), ctypes.c_void_p, w.DWORD, ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)]
    ole.CoCreateInstance.restype = ctypes.c_long
    shell.SHCreateItemFromParsingName.argtypes = [w.LPCWSTR, ctypes.c_void_p, ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)]
    shell.SHCreateItemFromParsingName.restype = ctypes.c_long
    check(ole.CoInitializeEx(None, 2))
    op = ctypes.c_void_p()
    item = ctypes.c_void_p()
    try:
        clsid = guid('3AD05575-8857-4850-9277-11B85BDB8E09')
        iid = guid('947AAB5F-0A5C-4C13-B4D6-4BF7836FC9F8')
        check(ole.CoCreateInstance(ctypes.byref(clsid), None, 1, ctypes.byref(iid), ctypes.byref(op)))
        # ALLOWUNDO, NOCONFIRMATION, SILENT, NOERRORUI, NORECURSION,
        # NORECURSEREPARSE, RECYCLEONDELETE, EARLYFAILURE.
        flags = 0x40 | 0x10 | 0x4 | 0x400 | 0x1000 | 0x8000 | 0x80000 | 0x100000
        check(method(op, 5, ctypes.c_long, w.DWORD)(op, flags))
        iid_item = guid('43826D1E-E718-42EE-BC55-A1E261C37BFE')
        check(shell.SHCreateItemFromParsingName(str(path), None, ctypes.byref(iid_item), ctypes.byref(item)))
        check(method(op, 18, ctypes.c_long, ctypes.c_void_p, ctypes.c_void_p)(op, item, None))
        release_leaf()
        check(method(op, 21, ctypes.c_long)(op))
        aborted = w.BOOL()
        check(method(op, 22, ctypes.c_long, ctypes.POINTER(w.BOOL))(op, ctypes.byref(aborted)))
        if aborted.value:
            raise OSError('Recycle operation was aborted; no permanent deletion fallback is used')
    finally:
        if item:
            method(item, 2, w.ULONG)(item)
        if op:
            method(op, 2, w.ULONG)(op)
        ole.CoUninitialize()
