import os
import stat
import threading
import time
from .models import Scan, Result, Candidate
from .policy import UnsafeFile, check_chain, reparse
from .paths import absolute, within
from .storage import JobLock
from . import native

MAX_CANDIDATES = 50000
MAX_SCANNED = 250000


def scan(policy, categories, cancel=None, progress=None):
    cancel = cancel or threading.Event()
    out = Scan()
    began = time.monotonic()
    now = time.time()
    roots = [r for r in policy.roots if r.category in categories]
    for category in categories:
        out.stats[category] = dict(files=0, bytes=0, eligible=0, reclaimable=0)
    seen = set()
    last_update = 0.0
    for root in roots:
        if cancel.is_set() or out.truncated:
            break
        try:
            check_chain(root.path)
            if not root.path.is_dir():
                continue
        except FileNotFoundError:
            continue
        except (OSError, UnsafeFile) as e:
            out.skipped += 1
            out.note('Skipped', root.path, str(e))
            continue
        stack = [root.path]
        while stack and not cancel.is_set() and not out.truncated:
            folder = stack.pop()
            try:
                check_chain(folder)
                with os.scandir(folder) as entries:
                    for entry in entries:
                        if cancel.is_set():
                            break
                        p = absolute(entry.path)
                        if any(within(p, x) for x in policy.exclusions):
                            out.skipped += 1
                            out.note('Skipped', p, 'Excluded by settings')
                            continue
                        try:
                            st = entry.stat(follow_symlinks=False)
                            if reparse(st):
                                raise UnsafeFile('Link or junction; not followed')
                            if stat.S_ISDIR(st.st_mode):
                                stack.append(p)
                                continue
                            key = os.path.normcase(str(p))
                            if key in seen:
                                continue
                            seen.add(key)
                            owner = policy.root_for(p)
                            # Categories outside the current selection cannot leak in.
                            if owner.category not in categories:
                                continue
                            stats = out.stats[owner.category]
                            out.scanned += 1
                            if out.scanned >= MAX_SCANNED:
                                out.truncated = True
                                out.note('Skipped', root.path, '250,000-file scan limit reached; narrow categories or exclusions.')
                            stats['files'] += 1
                            stats['bytes'] += st.st_size
                            owner, st = policy.validate(p, now)
                            candidate = Candidate(p, owner, st.st_size, st.st_mtime_ns, st.st_ctime_ns, st.st_dev, st.st_ino,
                                                  native.change_token(p, st.st_ino) if os.name == 'nt' else 0)
                            out.candidates.append(candidate)
                            stats['eligible'] += 1
                            stats['reclaimable'] += st.st_size
                            if len(out.candidates) >= MAX_CANDIDATES:
                                out.truncated = True
                                out.note('Skipped', root.path, '50,000-file safety limit reached. Clean this batch and rescan.')
                                break
                        except (UnsafeFile, PermissionError, FileNotFoundError) as e:
                            out.skipped += 1
                            out.note('Skipped', p, str(e))
                        except OSError as e:
                            out.failed += 1
                            out.note('Failed', p, str(e))
                        if out.truncated:
                            break
                        if progress and time.monotonic() - last_update >= 0.2:
                            progress(out.scanned, len(out.candidates))
                            last_update = time.monotonic()
            except (OSError, UnsafeFile) as e:
                out.skipped += 1
                out.note('Skipped', folder, str(e))
    if 'recycle' in categories and not cancel.is_set():
        try:
            count, size = native.recycle_info()
            out.stats['recycle'].update(files=count, bytes=size)
        except OSError as e:
            out.note('Skipped', 'Recycle Bin', str(e))
            out.skipped += 1
    out.cancelled = cancel.is_set()
    out.duration = time.monotonic() - began
    return out


def clean(preview, policy, mode='dry-run', authorized=False, prefetch_authorized=False,
          cancel=None, progress=None, lock_dir=None):
    if mode not in ('dry-run', 'permanent', 'recycle'):
        raise ValueError('Unknown cleanup mode')
    if mode != 'dry-run' and not authorized:
        raise PermissionError('Explicit cleanup authorization is required')
    if preview.cancelled:
        raise ValueError('Scan was cancelled; complete a new scan before cleaning')
    cancel = cancel or threading.Event()
    out = Result(scanned=preview.scanned, skipped=preview.skipped, failed=preview.failed, mode=mode)
    out.details = list(preview.details)
    began = time.monotonic()
    with JobLock(lock_dir):
        for i, item in enumerate(preview.candidates):
            if cancel.is_set():
                out.cancelled = True
                out.skipped += len(preview.candidates) - i
                break
            try:
                policy.validate(item.path, time.time(), item)
                if item.root.category == 'prefetch' and (policy.scheduled or not prefetch_authorized):
                    raise UnsafeFile('Prefetch needs separate manual confirmation')
                if mode == 'dry-run':
                    out.previewed += 1
                elif mode == 'permanent':
                    out.freed += native.permanent(item, policy, time.time())
                    out.cleaned += 1
                else:
                    out.recycled += native.recycle(item, policy, time.time())
                    out.cleaned += 1
            except (UnsafeFile, PermissionError, FileNotFoundError) as e:
                out.skipped += 1
                out.note('Skipped', item.path, str(e))
            except OSError as e:
                if getattr(e, 'winerror', None) in (5, 32, 33):
                    out.skipped += 1
                    out.note('Skipped', item.path, 'In use or access denied')
                else:
                    out.failed += 1
                    out.note('Failed', item.path, str(e))
            if progress and (i % 25 == 0 or i + 1 == len(preview.candidates)):
                progress(i + 1, len(preview.candidates))
    out.duration = time.monotonic() - began
    return out
