"""Resolve a closed catalog of known locations; exclusions can only reduce it."""
import os
from pathlib import Path
from .models import Root


def absolute(path):
    return Path(os.path.abspath(os.fspath(path)))


def within(path, parent):
    try:
        return os.path.normcase(os.path.commonpath((str(absolute(path)), str(absolute(parent))))) == os.path.normcase(str(absolute(parent)))
    except ValueError:
        return False


def deduplicate(roots):
    # More specific roots retain their category when overlapping a broader root.
    unique = {}
    for root in roots:
        unique.setdefault(os.path.normcase(str(absolute(root.path))), Root(absolute(root.path), root.category))
    return sorted(unique.values(), key=lambda r: (-len(r.path.parts), str(r.path)))


def discover(environ=None):
    env = os.environ if environ is None else environ
    if os.name != 'nt' and environ is None:
        return []  # Never reinterpret a Linux /tmp as a Windows cleanup target.
    roots = []
    local = Path(env['LOCALAPPDATA']) if env.get('LOCALAPPDATA') else None
    profile = Path(env['USERPROFILE']) if env.get('USERPROFILE') else None
    windir = Path(env.get('WINDIR', env.get('SystemRoot', ''))) if env.get('WINDIR') or env.get('SystemRoot') else None
    protected = [profile / p for p in ('Desktop', 'Documents', 'Downloads', 'Pictures', 'Videos', 'Music', 'Saved Games')] if profile else []

    def add(path, category):
        if path is None or not path.is_absolute():
            return
        path = absolute(path)
        if path == Path(path.anchor) or (profile and path == absolute(profile)):
            return
        # Reject either direction of overlap, even when TEMP was misconfigured.
        if any(within(path, p) or within(p, path) for p in protected):
            return
        if windir and category == 'user_temp' and within(path, windir):
            return
        if local and category == 'user_temp' and path == absolute(local):
            return
        roots.append(Root(path, category))

    if local:
        add(local / 'Temp', 'user_temp')
    # TEMP is accepted only at the canonical user Temp root or below it.
    # An arbitrary environment override must never turn Documents into a target.
    if env.get('TEMP') and local and within(Path(env['TEMP']), local / 'Temp'):
        add(Path(env['TEMP']), 'user_temp')
    if windir:
        add(windir / 'Temp', 'system_temp')
        add(windir / 'Prefetch', 'prefetch')
        add(windir / 'Minidump', 'crash')
        add(windir / 'LiveKernelReports', 'crash')
    if local:
        add(local / 'CrashDumps', 'crash')
        for vendor in ('Google/Chrome/User Data', 'Microsoft/Edge/User Data'):
            base = local / vendor
            try:
                profiles = [p for p in base.iterdir() if p.name == 'Default' or p.name.startswith('Profile ')]
            except OSError:
                profiles = []
            for p in profiles:
                if p.is_symlink():
                    continue
                for cache in ('Cache', 'Code Cache', 'GPUCache'):
                    add(p / cache, 'browser')
        base = local / 'Mozilla/Firefox/Profiles'
        try:
            for p in base.iterdir():
                if not p.is_symlink():
                    add(p / 'cache2', 'browser')
        except OSError:
            pass
    return deduplicate(roots)
