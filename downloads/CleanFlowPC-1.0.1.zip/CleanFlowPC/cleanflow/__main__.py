import argparse
import sys
import threading
from .storage import Settings, History, data_dir
from .paths import discover
from .policy import Policy
from .scheduler import approval
from . import engine


def scheduled():
    settings = Settings()
    v = settings.values
    if sys.platform != 'win32' or not v['automatic']:
        return 0
    roots = [r for r in discover() if r.category == 'user_temp']
    if not roots or v['schedule_approval'] != approval(roots, v['days'], v['exclusions']):
        return 2  # Fail closed if paths or retention changed after approval.
    policy = Policy(roots, v['days'], v['exclusions'], scheduled=True)
    # The lock spans both scan and cleanup, preventing concurrent scheduled scans.
    # clean has its own job lock; a separate scheduled entry lock covers this run.
    from .storage import JobLock
    try:
        with JobLock(data_dir() / 'scheduled-entry'):
            scan = engine.scan(policy, {'user_temp'})
            result = engine.clean(scan, policy, 'permanent', authorized=True)
            History().add(result)
            if v['notifications']:
                from .native import notify
                notify('CleanFlow PC', f'{result.cleaned} temporary files cleaned')
            return 1 if result.failed else 0
    except RuntimeError:
        return 3


def main():
    parser = argparse.ArgumentParser(description='CleanFlow PC offline Windows cleaner')
    parser.add_argument('--scheduled', action='store_true', help='Run an explicitly approved schedule without a GUI')
    args = parser.parse_args()
    if args.scheduled:
        try:
            return scheduled()
        except Exception:
            # Never invoke Tk on an unattended error; a count-only diagnostic.
            try:
                from .models import Result
                History().add(Result(mode='scheduled-error', failed=1))
            except Exception:
                pass
            return 1
    if sys.platform != 'win32':
        print('CleanFlow PC targets Windows 10+. Source tests are portable; deletion is Windows-only.')
    from .gui import App
    App().mainloop()
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
