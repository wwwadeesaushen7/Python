import os
import stat
from pathlib import Path
from .paths import absolute, within, deduplicate

class UnsafeFile(ValueError):
    pass


def reparse(st):
    return stat.S_ISLNK(st.st_mode) or bool(getattr(st, 'st_file_attributes', 0) & 0x400)


def check_chain(path):
    """lstat every component, including ancestors of the approved root."""
    p = absolute(path)
    for part in [*reversed(p.parents), p]:
        st = part.lstat()
        if reparse(st):
            raise UnsafeFile('Symbolic link or reparse point')
    return st


class Policy:
    def __init__(self, roots, days=7, exclusions=(), scheduled=False):
        if type(days) is not int or not 1 <= days <= 3650:
            raise ValueError('Minimum age must be 1–3650 days')
        self.roots = deduplicate(roots)
        self.days = days
        self.exclusions = tuple(absolute(p) for p in exclusions if str(p).strip())
        self.scheduled = scheduled

    def root_for(self, path):
        p = absolute(path)
        for root in self.roots:
            if within(p, root.path) and p != root.path:
                return root
        raise UnsafeFile('Outside approved folders, or folder root')

    def validate(self, path, now, expected=None, check_token=True):
        raw = os.fspath(path)
        if '..' in Path(raw).parts or (os.name == 'nt' and (raw.startswith('\\\\') or ':' in raw[3:])):
            raise UnsafeFile('Traversal, network path or alternate data stream')
        p = absolute(path)
        root = self.root_for(p)
        if self.scheduled and root.category != 'user_temp':
            raise UnsafeFile('Scheduled jobs may only use user temporary files')
        if any(within(p, x) for x in self.exclusions):
            raise UnsafeFile('Excluded by settings')
        st = check_chain(p)
        if not stat.S_ISREG(st.st_mode):
            raise UnsafeFile('Not a regular file')
        if st.st_nlink != 1:
            raise UnsafeFile('Hard-linked file')
        if getattr(st, 'st_file_attributes', 0) & (0x1 | 0x4 | 0x1000 | 0x40000):
            raise UnsafeFile('Read-only, system or offline file')
        if now - st.st_mtime < self.days * 86400:
            raise UnsafeFile('Younger than retention threshold')
        if expected and (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns) != (
                expected.device, expected.inode, expected.size, expected.mtime_ns, expected.ctime_ns):
            raise UnsafeFile('File changed since scan; scan again')
        if check_token and expected and expected.change_token and os.name == 'nt':
            from .native import change_token
            if change_token(p, st.st_ino) != expected.change_token:
                raise UnsafeFile('File change time changed since scan')
        if expected and root != expected.root:
            raise UnsafeFile('Approved location changed')
        return root, st
