import json
import os
import sqlite3
import time
from dataclasses import asdict
from pathlib import Path

DEFAULTS = dict(theme='dark', days=7, notifications=True, frequency='daily', hour='10:00',
                automatic=False, schedule_approval=None, exclusions=[], startup=False,
                confirm_permanent=True)


def data_dir():
    base = os.environ.get('LOCALAPPDATA') if os.name == 'nt' else None
    return Path(base) / 'CleanFlowPC' if base else Path.home() / '.cleanflow-pc'


class Settings:
    def __init__(self, folder=None):
        self.folder = Path(folder) if folder else data_dir()
        self.path = self.folder / 'settings.json'
        self.values = dict(DEFAULTS, exclusions=[])
        self.warning = ''
        try:
            raw = json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(raw, dict):
                raise ValueError('Settings must be an object')
            self.values.update({k: v for k, v in raw.items() if k in DEFAULTS})
            self.validate()
        except FileNotFoundError:
            pass
        except (OSError, ValueError, TypeError):
            self.values = dict(DEFAULTS, exclusions=[])
            self.warning = 'Settings could not be read. Safe defaults restored; automatic cleaning is off.'

    def validate(self):
        v = self.values
        if type(v['days']) is not int or not 1 <= v['days'] <= 3650:
            raise ValueError('Minimum file age must be 1–3650 days')
        if v['theme'] not in ('dark', 'light') or v['frequency'] not in ('daily', 'weekly', 'logon'):
            raise ValueError('Invalid theme or frequency')
        import datetime
        datetime.datetime.strptime(v['hour'], '%H:%M')
        if not isinstance(v['exclusions'], list) or not all(isinstance(p, str) for p in v['exclusions']):
            raise ValueError('Invalid exclusions')
        if any(not Path(p).is_absolute() for p in v['exclusions']):
            raise ValueError('Exclusions must be absolute paths')
        for k in ('notifications', 'automatic', 'startup', 'confirm_permanent'):
            if type(v[k]) is not bool:
                raise ValueError('Invalid preference')
        if v['schedule_approval'] is not None and not isinstance(v['schedule_approval'], dict):
            raise ValueError('Invalid schedule approval')
        v['confirm_permanent'] = True  # A confirmation can never be disabled.

    def save(self):
        self.validate()
        self.folder.mkdir(parents=True, exist_ok=True)
        import tempfile
        fd, tmp = tempfile.mkstemp(prefix='settings-', suffix='.tmp', dir=self.folder)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump(self.values, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.path)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)


class History:
    def __init__(self, folder=None):
        self.folder = Path(folder) if folder else data_dir()
        self.folder.mkdir(parents=True, exist_ok=True)
        self.path = self.folder / 'history.sqlite3'
        with self.connect() as c:
            c.execute('CREATE TABLE IF NOT EXISTS runs (id INTEGER PRIMARY KEY, started REAL, summary TEXT)')

    def connect(self):
        return sqlite3.connect(self.path, timeout=10)

    def add(self, result):
        values = asdict(result)
        del values['details']  # Neither filenames nor contents are persisted.
        with self.connect() as c:
            c.execute('INSERT INTO runs(started, summary) VALUES (?,?)', (result.started, json.dumps(values)))
            c.execute('DELETE FROM runs WHERE id NOT IN (SELECT id FROM runs ORDER BY id DESC LIMIT 200)')

    def rows(self):
        with self.connect() as c:
            return [json.loads(r[0]) for r in c.execute('SELECT summary FROM runs ORDER BY id DESC LIMIT 200')]


class JobLock:
    """OS lock is released automatically on crashes; no stale PID guessing."""
    def __init__(self, folder=None):
        self.folder = Path(folder) if folder else data_dir()
        self.file = None

    def __enter__(self):
        self.folder.mkdir(parents=True, exist_ok=True)
        self.file = open(self.folder / 'cleanup.lock', 'a+b')
        self.file.seek(0)
        self.file.write(b'0')
        self.file.flush()
        self.file.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as e:
            self.file.close()
            self.file = None
            raise RuntimeError('Another CleanFlow cleanup job is already running') from e
        return self

    def __exit__(self, *args):
        if self.file:
            self.file.close()
            self.file = None
