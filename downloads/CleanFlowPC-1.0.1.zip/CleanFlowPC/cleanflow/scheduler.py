"""Current-user Windows Task Scheduler, XML registration, no elevation/passwords."""
import csv
import datetime as dt
import hashlib
import io
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from .native import require_windows

NS = 'http://schemas.microsoft.com/windows/2004/02/mit/task'


def command():
    if getattr(sys, 'frozen', False):
        return str(Path(sys.executable).absolute()), ['--scheduled']
    executable = Path(sys.executable)
    pythonw = executable.with_name('pythonw.exe')
    if pythonw.exists():
        executable = pythonw
    return str(executable), [str(Path(__file__).resolve().parent.parent / 'run_cleanflow.py'), '--scheduled']


def run(args):
    require_windows()
    result = subprocess.run(args, capture_output=True, timeout=30,
                            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    import locale
    def decode(data):
        if data.startswith((b'\xff\xfe', b'\xfe\xff')):
            return data.decode('utf-16', errors='replace')
        if len(data) > 2 and data[1] == 0:
            return data.decode('utf-16-le', errors='replace')
        return data.decode(locale.getpreferredencoding(False), errors='replace')
    if result.returncode:
        raise OSError((decode(result.stderr or result.stdout) or 'Task Scheduler command failed').strip())
    return decode(result.stdout)


def system_tool(name):
    require_windows()
    base = os.environ.get('SystemRoot') or os.environ.get('WINDIR')
    if not base:
        raise OSError('Windows system directory is unavailable')
    return str(Path(base) / 'System32' / name)


def user_sid():
    output = run([system_tool('whoami.exe'), '/user', '/fo', 'csv', '/nh'])
    for row in csv.reader(io.StringIO(output)):
        for field in row:
            if re.fullmatch(r'S-1-\d+(?:-\d+)+', field.strip()):
                return field.strip()
    raise OSError('Could not determine the current Windows user SID')


def task_name(sid):
    return 'CleanFlowPC-' + hashlib.sha256(sid.encode()).hexdigest()[:12]


def approval(roots, days, exclusions):
    return dict(roots=sorted(os.path.normcase(str(r.path)) for r in roots if r.category == 'user_temp'),
                days=days, exclusions=sorted(exclusions))


def build_xml(sid, frequency, hour, executable, args, now=None):
    if frequency not in ('daily', 'weekly', 'logon'):
        raise ValueError('Unsupported schedule frequency')
    parsed = dt.datetime.strptime(hour, '%H:%M').time()
    now = now or dt.datetime.now()
    start = dt.datetime.combine(now.date(), parsed)
    if frequency == 'weekly':
        start += dt.timedelta(days=(0 - start.weekday()) % 7)
        if start <= now:
            start += dt.timedelta(days=7)
    elif start <= now:
        start += dt.timedelta(days=1)
    ET.register_namespace('', NS)
    task = ET.Element('Task', version='1.2', xmlns=NS)
    def child(parent, name, value=None, **attrs):
        el = ET.SubElement(parent, name, attrs)
        if value is not None:
            el.text = str(value)
        return el
    reg = child(task, 'RegistrationInfo')
    child(reg, 'Description', 'CleanFlow PC: approved user temporary files only. No Prefetch. No elevation.')
    triggers = child(task, 'Triggers')
    if frequency == 'logon':
        trigger = child(triggers, 'LogonTrigger')
        child(trigger, 'Enabled', 'true')
        child(trigger, 'UserId', sid)
        child(trigger, 'Delay', 'PT2M')
    else:
        trigger = child(triggers, 'CalendarTrigger')
        child(trigger, 'StartBoundary', start.isoformat())
        child(trigger, 'Enabled', 'true')
        if frequency == 'daily':
            child(child(trigger, 'ScheduleByDay'), 'DaysInterval', '1')
        else:
            weekly = child(trigger, 'ScheduleByWeek')
            child(weekly, 'WeeksInterval', '1')
            days = child(weekly, 'DaysOfWeek')
            child(days, 'Monday')
    principals = child(task, 'Principals')
    principal = child(principals, 'Principal', id='CurrentUser')
    child(principal, 'UserId', sid)
    child(principal, 'LogonType', 'InteractiveToken')
    child(principal, 'RunLevel', 'LeastPrivilege')
    settings = child(task, 'Settings')
    child(settings, 'MultipleInstancesPolicy', 'IgnoreNew')
    child(settings, 'DisallowStartIfOnBatteries', 'false')
    child(settings, 'StopIfGoingOnBatteries', 'false')
    child(settings, 'StartWhenAvailable', 'true')
    child(settings, 'RunOnlyIfNetworkAvailable', 'false')
    child(settings, 'Enabled', 'true')
    child(settings, 'ExecutionTimeLimit', 'PT1H')
    actions = child(task, 'Actions', Context='CurrentUser')
    action = child(actions, 'Exec')
    child(action, 'Command', executable)
    child(action, 'Arguments', subprocess.list2cmdline(args))
    child(action, 'WorkingDirectory', str(Path(executable).parent))
    return ET.tostring(task, encoding='unicode')


class Scheduler:
    def __init__(self):
        self.sid = user_sid()
        self.name = task_name(self.sid)
        self.tool = system_tool('schtasks.exe')

    def register(self, frequency, hour):
        executable, args = command()
        xml = build_xml(self.sid, frequency, hour, executable, args)
        fd, path = tempfile.mkstemp(suffix='.xml', prefix='cleanflow-task-')
        try:
            with os.fdopen(fd, 'w', encoding='utf-16') as f:
                f.write('<?xml version="1.0" encoding="UTF-16"?>\n' + xml)
            run([self.tool, '/Create', '/TN', self.name, '/XML', path, '/F'])
        finally:
            Path(path).unlink(missing_ok=True)

    def enable(self):
        run([self.tool, '/Change', '/TN', self.name, '/ENABLE'])

    def disable(self):
        run([self.tool, '/Change', '/TN', self.name, '/DISABLE'])

    def delete(self):
        run([self.tool, '/Delete', '/TN', self.name, '/F'])

    def status(self):
        xml = run([self.tool, '/Query', '/TN', self.name, '/XML'])
        task = ET.fromstring(xml.lstrip('\ufeff'))
        enabled = task.find(f'{{{NS}}}Settings/{{{NS}}}Enabled')
        return 'Enabled' if enabled is not None and enabled.text == 'true' else 'Disabled'


def startup(enabled):
    require_windows()
    import winreg
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r'Software\Microsoft\Windows\CurrentVersion\Run') as key:
        if enabled:
            exe, args = command()
            args = [a for a in args if a != '--scheduled']
            winreg.SetValueEx(key, 'CleanFlowPC', 0, winreg.REG_SZ, subprocess.list2cmdline([exe, *args]))
        else:
            try:
                winreg.DeleteValue(key, 'CleanFlowPC')
            except FileNotFoundError:
                pass
