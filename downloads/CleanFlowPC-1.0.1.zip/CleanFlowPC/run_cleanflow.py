"""Visible startup failures for source, pythonw and windowed PyInstaller builds."""
import datetime
import os
from pathlib import Path
import sys
import tempfile
import traceback


def save_startup_error(details, folder=None):
    """Best-effort local traceback. Never inspect environment values or file contents."""
    folders = [Path(folder)] if folder is not None else [
        Path(os.environ.get('LOCALAPPDATA') or tempfile.gettempdir()) / 'CleanFlowPC',
        Path(tempfile.gettempdir()) / 'CleanFlowPC',
    ]
    for directory in folders:
        try:
            directory.mkdir(parents=True, exist_ok=True)
            path = directory / 'startup-error.log'
            # Only the latest startup error is retained; avoid unbounded logging.
            report = f'CleanFlow PC startup failure — {datetime.datetime.now().isoformat()}\n'
            report += f'Python {sys.version.split()[0]}\n\n{details}'
            path.write_text(report[-65536:], encoding='utf-8')
            return path
        except OSError:
            continue
    return None


def show_startup_error(message):
    if sys.platform == 'win32':
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, message, 'CleanFlow PC could not start', 0x10)
        except Exception:
            pass


def launch(main_function=None, log_folder=None):
    try:
        if main_function is None:
            from cleanflow.__main__ import main
            main_function = main
        return main_function()
    except Exception as error:
        details = traceback.format_exc()
        log = save_startup_error(details, log_folder)
        message = f'{type(error).__name__}: {error}\n\n'
        message += f'Details were saved to:\n{log}' if log else 'The error log could not be saved.'
        message += '\n\nIf running from source, extract the entire ZIP before opening START_CLEANFLOW.bat.'
        try:
            if sys.stderr is not None:
                sys.stderr.write(details + '\n' + message + '\n')
        except (OSError, AttributeError):
            pass
        if '--scheduled' not in sys.argv[1:]:
            show_startup_error(message)
        return 1


if __name__ == '__main__':
    raise SystemExit(launch())
