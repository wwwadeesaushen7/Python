# Build on Windows. onedir avoids a large extraction at every scheduled launch.
from PyInstaller.utils.hooks import collect_submodules
a = Analysis(['run_cleanflow.py'], pathex=[], binaries=[], datas=[],
             hiddenimports=collect_submodules('cleanflow'), hookspath=[], runtime_hooks=[], excludes=[])
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='CleanFlowPC',
          debug=False, bootloader_ignore_signals=False, strip=False, upx=False,
          console=False, uac_admin=False)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='CleanFlowPC')
