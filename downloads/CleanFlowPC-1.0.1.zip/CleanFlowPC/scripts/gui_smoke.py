"""Run with an X display or Windows desktop. Never deletes any files."""
import os
from pathlib import Path
import sys
import tempfile
import time
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from cleanflow.gui import App
from cleanflow.models import Root
from cleanflow.storage import Settings, History

with tempfile.TemporaryDirectory() as temporary:
    base = Path(temporary).resolve()
    temp = base / 'approved'
    temp.mkdir()
    old = temp / 'old.tmp'
    old.write_bytes(b'test')
    stamp = time.time() - 10 * 86400
    os.utime(old, (stamp, stamp))
    for i in range(3000):
        file = temp / f'file-{i}.tmp'
        file.write_bytes(b'test')
        if i % 2 == 0:
            os.utime(file, (stamp, stamp))
    settings = Settings(base / 'settings')
    settings.values['notifications'] = False
    errors = []
    with patch('cleanflow.gui.discover', return_value=[Root(temp, 'user_temp')]):
        app = App(settings=settings, history=History(base / 'settings'))
        app.report_callback_exception = lambda *args: errors.append(str(args[1]))
        for page in app.nav:
            app.show(page)
            app.update()
        app.show('Junk Scanner')
        heartbeats = []
        def heartbeat():
            heartbeats.append(time.monotonic())
            app.after(10, heartbeat)
        app.after(10, heartbeat)
        app.start_scan()
        deadline = time.monotonic() + 15
        while app.busy and time.monotonic() < deadline:
            app.update()
            time.sleep(.01)
        assert not app.busy, 'Scan worker timed out'
        assert len(app.preview.candidates) == 1501
        assert app.preview.scanned == 3001
        assert heartbeats, 'UI event loop did not respond during scan'
        app.show('Clean Files')
        app.start_clean()  # Default mode is dry-run.
        while app.busy and time.monotonic() < deadline:
            app.update()
            time.sleep(.01)
        assert not app.busy
        assert app.last_result.previewed == 1501
        assert old.exists()
        app.details()
        app.update()
        for child in list(app.winfo_children()):
            import tkinter as tk
            if isinstance(child, tk.Toplevel):
                child.destroy()
        app.show('Settings')
        app.theme_var.set('light')
        app.save_preferences()
        app.update()
        assert settings.values['theme'] == 'light'
        app.theme_var.set('dark')
        app.save_preferences()
        app.show('Dashboard')
        app.update()
        if os.environ.get('CLEANFLOW_SCREENSHOT'):
            from PIL import ImageGrab
            app.geometry('1180x800+30+30')
            app.update()
            ImageGrab.grab(bbox=(30, 30, 1210, 830)).save(os.environ['CLEANFLOW_SCREENSHOT'])
        app.destroy()
        assert not errors, errors
        print('GUI smoke passed: six pages, 3,001-file threaded scan with UI heartbeat, 1,501-file dry-run, details, theme persistence.')
